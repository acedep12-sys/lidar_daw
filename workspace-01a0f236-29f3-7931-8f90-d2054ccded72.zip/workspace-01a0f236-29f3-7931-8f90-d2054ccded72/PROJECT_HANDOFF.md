# SquadAI — Session Handoff Guide

**Written:** 2026-09-27. **Purpose:** hand this to a new session so it can continue
without re-deriving context. Read this top to bottom before touching anything.

## 0. READ FIRST — where the last session ended (2026-09-29)

**ACTIVE BUG (top priority): menu background disappeared after the user ran
`SquadAI_ImportMenuFlagWave.py`.**

Diagnosis (high confidence): the user ran a STALE copy of the flag script — the
first build created `M_MenuFlagWave` as a **UI-domain** material. The S16-FLAG2
menu code draws that material with Canvas `DrawMaterial`, which renders
UI-domain materials as NOTHING -> blank background. (This also implicitly
proves the S16-FLAG2 code COMPILED and runs — i.e. the big uncompiled backlog
including the whole S15 trench line built successfully, though the user never
said so explicitly. Trench system in-map status: unknown.)

**Give the user these fixes immediately (either works):**
1. Re-download the CURRENT `SquadAI_MenuFlagWave.zip` and re-run its script —
   it rebuilds the material as Surface/Unlit and the flag waves. OR:
2. In the Content Browser delete the folder `/Game/SquadAI/MenuFlagWave`,
   restart -> static background returns (fallback path).

**S16-FLAG5 (newest): flag re-enabled by default (cvar 1) at user's request —
his exact order: (1) Content Browser: delete /Game/SquadAI/MenuFlagWave,
(2) re-download BOTH current zips, (3) copy source + compile, (4) run the NEW
SquadAI_ImportMenuFlagWave.py, (5) launch. Expected log line on success:
`[SquadAIMenu] S16-FLAG5: waving-flag background ACTIVE`. If menu/bg still
wrong, get Saved/Logs/*.log — and check for the S16-FLAG3 warning line.**

**Already shipped hardening (`S16-FLAG3`, in the current code zip, needs his
compile):** (a) the HUD now accepts M_MenuFlagWave ONLY if Surface-domain — a
stale UI-domain material is ignored with a `[SquadAIMenu] S16-FLAG3` warning,
so the menu can never go blank from this again; (b) fixed a second bug found
during this: S16-FLAG2 had accidentally spliced the background texture-fallback
if/else-if chain in AutoResolveMissingTextures (the /Game/Textures uasset
fallback had rebound to the wrong if — with the loose PNG missing this ALSO
blanks the background).

Also: the user's chat client lagged one message behind; he restarted in a new
session. Do not re-ask for context — this file is the context.

**UPDATE (later same day): user says "no menu shows up" at all — even the
menu itself, not just the background. No log received; chat client glitched.
Shipped `S16-FLAG4` kill switch (cvar `SquadAI.MenuFlagWave`, default 0): with
the current code zip compiled, the menu code path is byte-for-byte the stock
static-image behaviour. Recovery sequence given to the user: (1) delete
/Game/SquadAI/MenuFlagWave in Content Browser, (2) compile the NEWEST code
zip, (3) if the menu is STILL missing, it is NOT the flag work — request
Saved/Logs/ProjectName.log immediately and look for errors around
ASquadAIMainMenuHUD / SquadAIMainMenuGameMode / the menu map.**

Verify with him early: (a) did the compile of the code zip succeed (expected
yes), (b) menu background restored, (c) flag waving after re-running the NEW
script, (d) trench dresser placed yet + screenshots.

---

---

## 1. What this project is

A **UE 5.7 open-world tactical FPS**, Iran–Iraq war setting. The assistant only
ever edits the `SquadAI` module; the full Unreal project lives on the user's
machine at `C:\lidar_mission\data` and the assistant has **no access to it**.

Workflow: assistant edits a drop-in source tree, zips it, user downloads,
compiles locally, plays, and reports back with screenshots and logs.

### Setting (get this right — the user has corrected it before)
- **Khuzestan / Dehlavieh, Iran.** NOT an Arabic/Gulf village.
- Reference term for imagery: **دفاع مقدس**.
- Walls are **kahgel**: warm red-ochre mud-and-straw plaster over adobe brick.
  **Not** pale grey exposed brick.
- Quality bar the user names explicitly: **Call of Duty**.

---

## 2. Hard constraints (standing instructions — do not violate)

| Constraint | Detail |
|---|---|
| Engine | **UE 5.7 only.** Never use APIs absent in 5.7. |
| Scope | Only the `SquadAI` folder may be edited. |
| Backups | Never overwrite the user's originals. Deliver via `source/SquadAI`. |
| Permission | **No code changes without per-batch permission.** |
| Chunking | **Break work into small pieces.** The assistant has repeatedly stalled on large steps. |
| Brevity | **Avoid over-explaining** in replies. |
| Packaging | Material deliverables go in a folder containing **ONLY materials**. Never bundle source/docs with them. |
| Textures | User wants **prebuilt textures** from the assistant; running the Python generator locally was "too heavy". UE import must be automated. |
| GitHub | Skip. User downloads and pushes manually. |
| UI | Never recreate UI views from scratch. (Reversed only for materials/textures, which the assistant authors itself.) |
| Pack UMG widgets | Stay in project as backup, must never appear in game. Deny-by-default, no deletions. |
| Localization | External `SquadAILocalization.ini` stays; maximise coverage. Arabic added as 3rd language. |
| Preserved behaviour | Distant enemy spawning is **intentional** — keep it. |
| Dropped | Sandbags (user has own mesh/material). Leader character-swap (shelved). |

---

## 3. Workspace layout

```
/home/user/
├── PROJECT_HANDOFF.md            <- this file (single source of truth on state)
├── SquadAI_Setup_And_Code.zip    <- MAIN deliverable (SquadAI_Setup + source/SquadAI + art/tools + this file)
├── SquadAI_TrenchMaterials.zip   <- 34 MB: 25 trench textures + SquadAI_ImportTrenchMaterials.py + README.
│                                    THE ONLY COPY of these textures anywhere. Do not lose it.
├── SquadAI_MenuFlagWave.zip      <- 2.6 MB: menu bg + flag mask + SquadAI_ImportMenuFlagWave.py (S16-FLAG)
├── SquadAI_MD_Documentation.zip  <- 84 archived docs, exists nowhere else loose
├── SquadAI_Setup/                <- setup docs + village-era importer + MATERIAL_RECORDS.md (read it)
├── art/tools/                    <- texture generators: texgen.py/texlib.py/mat_* (village era)
│                                    + make_trench_pbr.py / make_trench_pbr2.py (trench texture pipeline notes/params)
├── source/SquadAI/               <- the drop-in UE module (source of truth for code)
│   └── {Public,Private}/Environment/TrenchDetailSplineActor.{h,cpp}  <- the trench dresser (S15 line)
└── uploads/                      <- user files: 2 trench screenshots (2026-09-29), menu bg PNG,
                                     old logs (TPWeaponCombatSystem.txt, log2.txt, log123.txt)
```

Rules learned the hard way:
- **Keep zip XOR unzipped folder, never both** — workspace snapshots have a
  ~128 MB cap and an oversized snapshot once silently dropped files AND
  reverted source edits. `du -sh` before ending a turn with big binaries.
- After ANY size incident: re-grep the newest `S1x-` markers in
  `source/SquadAI` to confirm edits survived.
- Zip rebuild recipes:
  - code: `cd /home/user && cp PROJECT_HANDOFF.md SquadAI_Setup/PROJECT_HANDOFF.md && rm -f SquadAI_Setup_And_Code.zip && zip -q -r SquadAI_Setup_And_Code.zip SquadAI_Setup source/SquadAI art/tools PROJECT_HANDOFF.md`
  - materials: unzip, edit, `rm -f <zip> && zip -q -r <zip> <folder> && rm -rf <folder>`
- **Always tell the user to re-download after every rebuild** — he has compiled
  stale zips twice.

---

## 4. Texture / material pipeline

> **STATUS: the numpy/procedural village pipeline below is HISTORICAL.** The user
> judged procedural textures ugly and does not use the village system. The live
> pipeline is: AI-generate photoreal source images -> derive N/R maps -> ship
> prebuilt textures + a UE-editor Python import script that builds the materials
> (see the two materials zips). Params/recipes for the trench textures are noted
> in `art/tools/make_trench_pbr*.py`. Village-era detail kept for reference:

### Generating
```bash
cd /home/user/art/tools
python3 texgen.py <mudbrick|ground|rubble|wood> --res 2048 --seed <N> --preview
```
Outputs 5 maps: `_BC` `_N` `_ORM` `_H` `_DN`. ~70–85 s at 2K. All seamlessly tileable.

### Channel set (locked with user)
Albedo + Normal (DirectX -Y) + packed ORM + Height (16-bit) + Detail Normal. 2K PNG.

### Status of the four authored surfaces

| Surface | Generator | Seed | Normal strength | **packed nz** | Delivered |
|---|---|---|---|---|---|
| Rubble | `mat_rubble` | 2301 | 4.0 | 0.797 (most relief) | yes, downloaded |
| Kahgel wall | `mat_mudbrick` | 1201 | 2.0 | 0.826 | yes, downloaded |
| Wood beam | `mat_wood` | 4501 | 2.2 | 0.856 | **zip still in workspace** |
| Ground dirt | `mat_ground` | 3401 | 1.7 | 0.875 (flattest) | yes, downloaded |

> **Always quote nz in PACKED space** (`_N.png` stores `nz*0.5+0.5`). Reading the
> blue channel raw once caused a whole wasted calibration round.

### Importing into UE
User runs `SquadAI_ImportVillageTextures.py` in the UE editor. It imports all 5
maps with correct per-map settings, builds `M_Village_<Surface>` + `MI_`, and
also builds `M_MortarDangerDecal`.

Key importer facts:
- `WORLD_TILE_SIZE_CM = 175.0` (was 400 — a 4 m tile, which is why surfaces
  looked flat and blobby). Tunable live on the MI via `WorldTileSizeCM`.
- `NormalIntensity` param (default 1.6) multiplies normal XY — tune live.
- Box-projected world UVs (dominant normal axis), so texel density is identical
  on every scaled cube.
- ORM sampler must be `SAMPLERTYPE_MASKS`.
- Normal blend is built from **math nodes**, not `BlendAngleCorrectedNormals`
  (missing on the user's install).
- **All connections go through `_conn` / `_conn_prop` wrappers** that log and
  collect failures, and the script prints a loud summary. This exists because
  `connect_material_expressions` fails *silently*.
- `build_instance` returns early if the MI exists — it sets **no** parameter
  overrides, so existing MIs correctly inherit new parent defaults.

**Last confirmed import (log 92150): `All material connections verified OK.`**
Mudbrick, GroundDirt, Rubble + decal all built. **Wood not yet imported.**

---

## 5. Code changes by marker

All edits are tagged in-source. `grep -rn "S13-" source/SquadAI` etc.

| Marker | What |
|---|---|
| `S9-FIX`, `S10-FIX` | earlier compile/ownership fixes |
| `S10-GEO` | building geometry detail pass |
| `S11-AI` | QuestZone fallback so enemies always resolve a goal |
| `S11-DIAG` | cvar **`SquadAI.DebugEnemyGoals 1`** — logs per-enemy goal source, distance, MoveTo result, navmesh projection |
| `S11-FX` | mortar danger ring redesign (superseded by S13-FX) |
| `S11-HUD` | top-right weapon plate — **user confirmed working** |
| `S12-INPUT` | single-owner `I`/`Tab`/`Esc` handling |
| `S12-DOWN` | downed-ally body location |
| `S13-AI` | enemy engagement hold |
| `S13-FX` | mortar danger **decal** |
| `S13-GEO` | lego seams, roof gaps, ground embed |
| `S14-INPUT` | inventory/pause "opens then instantly closes" — paused-frame tick-order race |
| `S14-FIX` | C4130 pointer-compare of string literals in STTask_EnemyMission (bGoalIsThreat bool) |
| `S14-AI` | direct-combat charge + grenade spam — hold line unified at 2200, entrenched-only frags |
| `S14-RANGE` | player damage trace 15000 → 40000 (distant spawns at ~300 m were unhittable) |
| `S14-NAV` | mission goal grounding: project with ±100 m vertical extent + walk-back partial advance |
| `S14-NAVDIAG` | runtime navmesh census (12 s + every 60 s): nav actors, gen mode, tile count, bounds |
| `S14-HIT` | pooled enemies unhittable: WakeEnemy stamped "CharacterMesh" (ignores Visibility) — archetype restore + pack-health reset + `SquadAI.DebugPlayerHits` cvar |
| `S14-POOL` | recycled corpses woke invisible: full un-ragdoll + mesh re-attach + archetype relative transform + montage stop + all-component `bIsDead?` clear + sleep-side physics off |
| `S14-POOL-B` | regression fix: SetCollisionProfileName early-outs on unchanged name → sleep's mesh NoCollision survived wake; enabled state now restored explicitly from archetype |
| `S14-POOL2` | recycled enemies STILL invisible: pack death sequence hides mesh COMPONENTS (actor-level unhide insufficient) — wake now mirrors CompleteRevive: velocities zeroed, SetVisibility(true)+SetHiddenInGame(false) on main + ALL extra skeletal meshes, InitializeAnimation |
| `S14-STAB` | stability batch: Bodies.Num() guards ("Invalid Bodies" spam); gravity re-enabled on every ragdoll start (re-downed allies floated — revive disables mesh gravity); grenades skip radial impulse on downed-ALIVE soldiers; Easy tuning softened (dmg 0.70→0.45, acc 0.40→0.28) |
| `S14-LEAD` | leader cover-danced/stopped en route: perception threat froze the march even for distant contacts — combat hold now requires the threat actor within StopForHostileRange |
| `S14-GHOST` | hostile census every 20 s: one [GhostCensus] line per living enemy (pos, dist-to-player, visibility, controller, StateTree running, move mode, HP) + totals — pinpoints "HUD count climbs but map looks empty" |
| `S14-COUNT` | rising HUD count + Clear quest never completing: dead pooled enemies stayed in SpawnedEnemies; SleepEnemy's health reset made them read "alive" again in CleanupDeadEnemies — corpses now dropped from tracking at death and sleepers skipped |
| `S14-ARAB` | Arabic "not set up": SquadAILocalization.ini created by an older build lacked all [*.ar] sections and the loader never upgraded existing files — template keys missing from the user file are now merged on load/reload (user values win) and appended to the ini |
| `S14-END` | post-campaign endless waves: SpawnerTriggers fire on player overlap regardless of mission state — after the last mission a trigger re-armed a bLoopWaves spawner (infinite waves → GPU ground down until timeout). ActivateSpawner now refuses when ALL MissionZones are Completed |
| `S15-TRENCH` | NEW `ATrenchDetailSplineActor` ("Trench Detail Dresser", Environment/): spline-driven trench dressing — duckboards, revetment planks + posts, corrugated sheets, barrels, ammo cans, wire pickets + strands, tarp awnings, firing steps, casings/stones/scorch. HISM-batched, ground-traced, seeded; deliberately NO sandbags/crates (user assets) |
| `S15-PBR` | photoreal PBR for the trench dresser (user rejected the flat village-style tints): `SquadAI_TrenchMaterials.zip` — 13 seamless 2K textures (AI-photoreal sources, seam-fixed, derived N/R maps) + UE import script building 4 world-aligned (triplanar) materials + translucent scorch decal. Actor: new `ScorchMaterial` slot; authored materials now shown untinted (tint only on primitive fallback) |
| `S15-TRENCH2` | pre-compile realism pass on the dresser: duckboards became individual planks (gaps + height jitter), corrugated sheets got 5 half-embedded ribs, firing steps got wooden tread planks, tarps became pitched two-panel awnings with tie posts, 3 wire strands, brass casings decoupled from the rust metal material, NEW bOverheadCover (plank+sheet roof sections spanning berm to berm) and NEW bCommWire (field-phone poles one side + 3-segment sagging catenary line) |
| `S15-TRENCH4` | COD-vibe pass (researched WW1/COD trench env art): bContinuousShoring (wall step 400→175 cm, revet 80%/corr 60% — walls read fully shored; firing-step/tarp odds rate-normalized), bDugouts (timber door frame + fake-depth black doorway plane on NEW HISM_DugoutShadow + corrugated rain hood + dumped ammo cans), bCamoNetting (NEW HISM_Netting, 2 tilted panels berm-to-berm, M_TrenchNetting = masked-alpha two-sided net texture, falls back to ClothMaterial), bHelmets (NEW HISM_Helmet olive spheres on firing steps 30% / wire stakes 9%). +T_TrenchNetting_BC (RGBA 2K) + build_netting() in import script |
| `S15-TRENCH5` | polish: bUniqueSeedPerLocation (HashCombine(Seed, GridSnap(ActorLoc,10)) — multiple dressers never copy-paste), bBattleDamage (12% revetment panels collapsed 26–42°, sunk/skewed, posts skipped, 1–2 fallen planks at wall base), bConcertinaCoils (18%·density between stake pairs: 12-chord wire ring r=32 with axial drift ≈ spiral, berm-traced), camo nets got 4 corner support poles (traced height, skipped where the berm itself carries the net, <40 cm culled) |
| `S15-TRENCH6` | placement-quality polish: TraceGround overload returns surface normal (wall hits with N.Z<0.5 clamped to Up); duckboard sections AND individual planks, prayer rugs, scorch patches and fire-pit burn marks now slope-align via MakeFromZX(normal, yawdir) instead of sitting dead-flat; per-rebuild stats log `[TrenchDresser] built N instances in K/17 categories along M m (seed S)` |
| `S15-TRENCH7` | fix + polish existing (no new categories): removed unused `Along` in ScatterCampLife (C4189 warnings-as-errors compile risk); dugouts now scatter BEFORE camp life and record DugoutBuildMarks — camp furniture skips slots within 400 cm of a doorway; parapet wire sag now span-proportional AND each strand is a two-segment V so ends stay attached to stake tops; barrels slope-aware (upright drums tilt with ground via MakeFromZX, tipped drums lie IN the ground plane via VectorPlaneProject, positioned along the normal); stretcher poles+canvas hug the slope the same way |
| `S17-MVOL` | Menu-music volume setting: menu Settings screen gets a 5th row 'Menu music volume' (row ID 720, steppers 709/710, box 380->440) FA/EN, wired to the EXISTING persisted FSquadGameSettingsSaveData.MusicVolume (0.8 default) via the standard SaveSys Load/SaveSettings path; SetupActor now plays MenuThemeMusic with SpawnSound2D (volume = saved MusicVolume) instead of fire-and-forget PlaySound2D and keeps the UAudioComponent (Transient) + SetMenuMusicVolume(BlueprintCallable); stepper clicks apply LIVE via TActorIterator over setup actors. Menu HUD edited with python anchors only |
| `S17-LOOK` | Free mouse-look at spawn: camera only rotated while holding RMB because nothing set game input mode at gameplay start (only pause/inventory CLOSE paths did) — viewport kept UI-style capture after the deployment click. OnDeploymentVeilDismissed now forces PC->bShowMouseCursor=false + FInputModeGameOnly (SetConsumeCaptureMouseDown(false)) at the exact Enter-press moment |
| `S17-BRDG` | Spline bridge builder: NEW `ABridgeSplineActor` (Environment/, trench-dresser conventions: SceneRoot + spline + HISMs, OnConstruction full rebuild, LoadObject engine Cube/Cylinder, shared one-DMI-per-HISM tint OR authored material overrides shown as-is). Drag over river, stretch spline bank-to-bank (default 20 m straight): (1) plank deck laid ACROSS travel dir (PlankLength 55 + Gap 4 x DeckWidth 350 x 10, seeded yaw/roll/Z jitter via Roughness 0..1, Seed 1361) — HISM_Deck is BlockAll + SetCanEverAffectNavigation(true) so navmesh crosses (AI can use the bridge); (2) two longitudinal stringers (300 cm chord segments); (3) rails: posts both edges every 220 + top beam (and bMidRail) as chord runs between post tops; (4) piers every 550: cylinder legs at both edges LINE-TRACED down (ECC_Visibility, PierTraceDepth 4000, +40 sink) to riverbed else FixedPierLength 600, + horizontal cross brace under deck. Materials: Deck/Rail/PierMaterial overrides (assign S15 trench wood PBR) else wood tints. Rails/piers BlockAll but never affect navigation |
| `S17-STORY` | Deployment easing + story layer: (1) hooking the exact veil dismiss (Enter press in DrawDeploymentVeil) -> OnDeploymentVeilDismissed: 1.4 s full-screen black fade-in (DrawPostVeilFade, drawn LAST in DrawHUD) so spawn no longer 'jumps'; (2) onboarding hints: 4 sequential 6.5 s mini-banners (move/aim/revive/objectives) under the alert banner starting 2 s post-veil, once per level, FA/EN via SquadAIHUDLocal Section 'OnboardingHints' Hint1-4 (ini-overridable incl .ar); (3) story briefings: MissionZone Mission|Story = MissionBriefingTitle/Text (multiline FText, designer-localized) + Duration 12 -> ActivateMission calls QuestNativeHUD.ShowStoryCard — reuses the S17-NOTE reader card with military-green spine, no counter, 10-line cap; cards requested while the veil is still up are QUEUED (PendingStory*) and shown right after Enter. BlueprintCallable ShowStoryCard usable anywhere for cutscene-ish text beats |
| `S17-GRIP3` | One-click PERMANENT socket creation (editor button): UFUNCTION(CallInEditor) `CreateGripSocketOnSkeleton` on ASoldierCharacter (Soldier|Weapon Visual) — clones WeaponAttachSocketName from the template (GripSocketTemplateMesh or CDO-walk auto-discovery, refactored into shared helpers FindGripSocketTemplate/ResolveGripBone used by both GRIP2 runtime path and this) and ADDS a real USkeletalMeshSocket to the character's USkeleton asset (NewObject outer=skeleton, Skeleton->Modify + Sockets.Add + MarkPackageDirty), re-attaches immediately, log instructs to Save All to persist; only ADDS to the custom skeleton — mannequin/main assets untouched; errors guide (no skeleton / already exists / no template / no hand bone). Workflow: select character in level -> Details -> press button -> Ctrl+Shift+S |
| `S17-GRIP2` | Automatic grip cloning for swapped character meshes (upgrade of S17-GRIP, zero assets modified): when WeaponAttachSocketName is missing on the current mesh, ApplyEquippedWeaponAttachment now clones the socket at RUNTIME — template = GripSocketTemplateMesh UPROPERTY (Soldier|Weapon Visual, default None) else auto-discovered by walking GetClass()->Super CDOs for the mesh the Blueprint originally shipped with (the mannequin) and FindSocket'ing it; socket's parent bone mapped onto the new skeleton (exact name, else hand-bone candidates), weapon attached to that BONE with SetRelativeTransform(OffsetT * clonedSocketT) so designer offsets act in socket space exactly like on the mannequin; Warning log names template+bone. Falls through to the S17-GRIP name-fallback chain when no template socket found. Clone/child BPs unaffected assets-wise: pure in-memory attach math |
| `S17-GRIP` | Weapon-at-feet fix for custom character meshes: ApplyEquippedWeaponAttachment (SoldierCharacter.cpp) attached to WeaponAttachSocketName ('RifleSocket'); when the swapped-in skeleton lacks it, UE silently snaps the weapon to the MESH ROOT (feet, follows root motion) while anims still play. Now resolves before attaching: configured socket -> fallback list (RifleSocket/WeaponSocket/GunSocket/weapon_r/weapon_r_socket/hand_rSocket/hand_r/Hand_R/R_Hand/RightHand/mixamorig:RightHand/Bip001-R-Hand; DoesSocketExist covers bones) with Warning log naming the fallback; if NOTHING matches, Error log dumps the skeleton's hand/wrist bone names and keeps legacy behavior loudly. Designer fixes: add 'RifleSocket' socket on the new skeleton's hand_r (copy transform from mannequin) OR set WeaponAttachSocketName + Location/RotationOffset per character (all EditAnywhere, Soldier|Weapon Visual) |
| `S17-ALRT` | HUD pass for mission alerts: QuestNativeHUD lazily binds (first DrawHUD, AddUniqueDynamic) every AMissionZone.OnMissionAlert -> OnMissionZoneAlertReceived; static table maps ALL 18 S17 keys to FA/EN strings via SquadAIHUDLocal(Section 'MissionAlerts', Key = alert key) so the external SquadAILocalization.ini can override per-language incl. [MissionAlerts.ar]; styles: danger red 6 s (OverrunWarning/CounterattackIncoming/HVTEscaped/SpotterDesignated/IncomingArtillery/POWKilled), info amber 4.5 s (HVTDesignated/SupplyCrateTaken), success green 4.5 s (rest); DrawMissionAlertBanner top-center Y=92 below defend countdown, dark card + colored spine (house style), 0.25 s fade-in / 0.8 s fade-out, latest alert wins; unknown keys ignored (future-safe). HUD edits via python exact anchors |
| `S17-EVNT` | Batch 5b (FINAL mission-content batch) — dynamic ambient war events: NEW `AWarAmbienceDirector` (Environment/, drop ONE in level): randomized timer (40-90 s) fires weighted events around the player using existing systems only — (w4) distant shellfire echo (Large/MediumExplosionDistantSound + optional DistantArtilleryRumble, 4000-8000 cm, sound only), (w3) distant gunfire exchange (3-6 DefaultGunshotDistantSound shots, 0.25-0.9 s apart, wandering location + pitch/volume jitter), (w3) Farsi radio chatter burst (RadioChatterSubsystem.BroadcastRadioChatter, Khuzestan-river call signs Karkheh/Karun/Dez/Arvand, contexts SpotHostile/SuppressingFire/Flanking/MortarInbound), (w2) REAL harassment mortar salvo (TacticalMortarBarrageActor, 2 shells x120 dmg, lands 2600-4500 cm from player — whistle+danger ring fair warning). All events toggleable, intervals/distances/damage tunable; timers cleared in EndPlay; no MissionZone edits. Mission-content roadmap COMPLETE (batches 1-5) |
| `S17-NOTE` | Batch 5a — Fallen Notes collectibles: NEW `AFallenNoteActor` (Quest/): aged-paper engine-cube sheet + candle-pulse glow disc; walk-over pickup (200 cm & |dZ|<300, no hold); NoteTitle + NoteText (multiline FText, designer-localized, Farsi OK, body capped 8 lines); on collect: level-wide census (found X of Y via TActorIterator), meshes hidden, tick off, OnCollected delegate — purely ambient, NEVER gates missions/zones. HUD: QuestNativeHUD.ShowFallenNote(Title,Body,Duration,Found,Total) public BlueprintCallable + DrawFallenNoteOverlay drawn at end of DrawHUD — centered dark card + brass spine (defend-banner styling), gold title (DrawFarsiTextBounded centered), body lines, EN/FA counter footer (SquadAIHUDIsEnglish), 0.35 s fade-in / 1.2 s fade-out, ReadDuration default 10 s (min 3). HUD edits via python exact anchors (mixed-Farsi file rule) |
| `S17-POW` | Batch 4b — POW Rescue (any mission type, NO new files): MissionZone.POWCaptives links designer-placed AllySoldier/SoldierCharacter captives; zone BeginPlay freezes them 1 s after start (waits out possess/StartLogic window: StopLogic 'Captive' + StopMovementImmediately/DisableMovement + SetCanBeDamaged(false) while bPOWsInvulnerableWhileCaptive); zone Tick UpdatePOWRescue: stand within POWFreeRadius 250 for POWFreeTime 2.5 s (decay 1.5x) -> FreePOW: CanBeDamaged true, MOVE_Walking, StateTree Start/RestartLogic (EnemyPool wake recipe), AllySoldier.LeaderOverride = player (bPOWsFollowPlayer) so he fights alongside; captive death (pre-free only) -> alert POWKilled + FailMission (bFailOnPOWDeath); dead captives excluded from gate (no unwinnable wedge after restart); CompleteMission gate holds until all living captives freed; POWFreed persists across attempt restarts (freed men stay free), arrays Reset in SilentReset. Alerts: POWFreed / AllPOWsFreed / POWKilled (18 HUD keys total) |
| `S17-SUPP` | Batch 4a — Supply Run (any mission type): NEW `ASupplyCrateActor` (Quest/): wooden engine-cube crate + cyan pulsing disc; proximity pickup (220 cm & |dZ|<350, walk on to shoulder — no interact key), ONE crate carried at a time (TActorIterator check), crate hidden while carried; delivery when player enters delivery radius -> crate drops at feet, tick off, OnDelivered; ResetCrate returns to cached HomeTransform (undelivered crates reset on attempt restart). MissionZone: SupplyCrates array + optional SupplyDeliveryPoint actor (None = zone location) + SupplyDeliveryRadius 800 gates CompleteMission (all types); BindSupplyCrates (Activate/Restart, sets delivery target + resets), UnbindSupplyCrates (SilentReset); alerts SupplyCrateTaken / SupplyCrateSecured (+remaining log) / SupplyRunComplete; last delivery -> same type-aware recheck as sabotage (Reach=CompleteMission, Clear=CheckClearCompletion, Defend=timer retries). 15 HUD keys total |
| `S17-SPOT` | Batch 3b — enemy Artillery Spotter (Clear+Defend zones): bArtillerySpotter on MissionZone promotes the living hostile FARTHEST from the player (never the HVT) to a forward observer (health x2, OnDeath bound); while he lives, a repeating timer (interval 20 s, first 8 s, min 6) spawns ATacticalMortarBarrageActor at player pos + random scatter 700 cm and StartBarrage (actor provides whistle, HUD danger ring, radial damage, AI hearing, self-Destroy) with SpotterShellCount 4 / SpotterShellDamage 150; killing the spotter clears the shell timer + alert SpotterEliminated (shelling is pressure only — does NOT gate completion; barrage tick self-cancels when zone leaves Active). Armed in ActivateMission Clear+Defend cases and FinishRestartAttempt; ResetSpotterState in RestartCurrentAttempt + SilentReset. Alert keys: SpotterDesignated / IncomingArtillery / SpotterEliminated (12 HUD keys total) |
| `S17-SAB` | Batch 3a — Sabotage (Artillery Spotter deferred to next batch for size): NEW `ASabotageTargetActor` (Quest/): pulsing engine-shape marker disc (amber idle/fast planting, red accelerating strobe armed) + hidden olive satchel cube; PROXIMITY plant (260 cm & |dZ|<350, hold 3 s, progress decays 1.5x when leaving — deliberately no interact key, avoids S12-INPUT single-owner conflicts); fuse 10 s -> Detonate = barrel-recipe blast (AI hearing noise 6500, ApplyRadialDamageWithFalloff 900/25% 560..1400, audio-manager MediumExplosionClose fallback) — nearby ExplosiveBarrelActors chain for the fireball; actor NOT destroyed (zone reads state); OnDetonated/OnPlantProgress delegates + ResetTarget. MissionZone: SabotageTargets array gates CompleteMission (all types); on each detonation alert SabotageChargeDetonated + remaining count; last one -> SabotageComplete + type-aware recheck (Reach=CompleteMission, Clear=CheckClearCompletion, Defend=timer-tick retries); bind/reset on Activate/Restart, unbind on SilentReset |
| `S17-HVT` | Batch 2 — HVT Hunt on Clear zones: bHVTHunt promotes the nearest living hostile (3 s poll, first at 4 s post-activation) to a named officer — HealthComp Max*3 (tunable) + optional bodyguard buff (radius 1800, x1.5); CompleteMission HARD-GATED while officer lives (covers all completion paths; invalid weak-ptr counts as dead so missions can't wedge); kill -> alert HVTEliminated + instant complete (bCompleteOnHVTKill, default on); optional HVTEscapeTime countdown -> FailMission + HVTEscaped alert; state reset in Restart/SilentReset (ResetHVTState unbinds OnDeath — pooled recycling safe); alerts also HVTDesignated. Config: HVTName FText (Persian ok), multipliers, escape time |
| `S17-HOLD`+`S17-CNTR` | Batch 1 of the mission-content track (user green-lit; code-only, no new art): **Hold the Line** — Defend zones get bFailIfOverrun (OverrunRadius 1400 / OverrunEnemyCount 3 / OverrunGraceTime 12 s): 0.5 s census of living hostiles (IsEnemy+IsAlive, sleeper Z<-9000 skipped, 2D dist) inside the radius; pressure builds 1x/decays 2x; warning->FailMission on sustained overrun. **Counterattack** — bCounterattackAfterComplete (Delay 25 / Duration 45): CompleteMission schedules one LaunchCounterattack -> re-fires linked spawners then StopCounterattack deactivates; skipped/cancelled when ALL zones complete (S14-END rule); cleared in SilentResetForLoadRestore. New FOnMissionZoneAlert delegate (OnMissionAlert): OverrunWarning/OverrunCleared/CounterattackIncoming/CounterattackSpawningEnded — HUD can bind later. All state reset in Activate/Restart/SilentReset. NEXT BATCHES agreed: 2=HVT Hunt, 3=Sabotage+Artillery Spotter, 4=Supply Run+POW Rescue, 5=Fallen Notes+dynamic events. Excluded by user: vehicles, buildings, new character visuals, lighting |
| `S16-INTRO` | intro video before the menu + smoke wipe: drop silent `Content/Movies/MenuIntro.mp4` — HUD plays it fullscreen (aspect-cover, black otherwise) before any menu draws; menu theme music starts WITH it automatically (SetupActor plays MenuThemeMusic on BeginPlay, same frame); skip via Space/Enter/Esc/click; on video end (OnEndReached) smoke ramps IN 0.55 s over the frozen last frame (MediaTexture AutoClear=false), then menu draws under smoke clearing 1.35 s (pow 1.6 ease, 7 drifting rotated MenuSoftDustTexture billows + wash; wash-only fallback if texture missing); 4 s no-frame bail-out straight to menu; cvar `SquadAI.MenuIntro` default 1; file absent = exactly old behaviour |
| `S16-VID` | looping VIDEO menu background (user request, replaces flag-material idea): Build.cs +`MediaAssets`; HUD runtime-creates UMediaPlayer+UMediaTexture in InitBackgroundVideo() (BeginPlay) and plays `Content/Movies/MenuBackground.mp4` looped via OpenUrl(file://...) — ZERO editor setup, user just drops the MP4 there (exact filename). Draw priority video>flag>static; video waits for first frame (surface size>2) so static image shows meanwhile — no black flash; DrawTexture path = correct gamma (no darkening). Cvar `SquadAI.MenuVideo` default 1; file absent = old behaviour. H.264 MP4 recommended, seamless loop |
| `S16-FLAG7` | USER REJECTED flag v1 after seeing it live: (a) whole image drew DARKER (Canvas DrawMaterial emissive/gamma path differs from DrawTexture), (b) the soldier's HEAD wobbled (mask erode 9px + blur 14px bled distortion back over the head edges), (c) motion 'not natural' (2 pure sines too regular). Reverted: cvar `SquadAI.MenuFlagWave` default back to 0 (static image); draw path + guards kept for a future v2. V2 TODO if user asks again: fix gamma (match DrawTexture brightness — e.g. sample linear or pow 1/2.2), rebuild mask with much stronger protection around the soldier (erode more, blur less, hand-check head/arm), replace pure sines with 2-3 layered waves at non-integer frequency ratios + slight amplitude noise, amplitude ramp from fabric anchor points |
| `S16-FLAG6` | ROOT CAUSE of black/no background FOUND via user's editor log: import script crashed at `set_editor_property(\"used_with_ui\", True)` — property REMOVED in UE 5.7 — leaving a half-built black M_MenuFlagWave that the FLAG3 domain guard could not distinguish from a good one. Fixes: script wraps shading-model set in try/except (used_with_ui removed) + adds scalar param `FlagWaveOK`=1.0 as the LAST graph step (gates emissive); C++ guard now ALSO requires GetScalarParameterValue(FlagWaveOK)>0.5 — half-built materials rejected with `[SquadAIMenu] S16-FLAG3/6` warning and static bg kept |
| `S16-FLAG5` | user wants the flag ON: cvar `SquadAI.MenuFlagWave` default flipped 0->1 (safe: FLAG3 guard only accepts a valid Surface-domain material, else static image); accept path logs `[SquadAIMenu] S16-FLAG5 ... ACTIVE`. Runtime off-switch: `SquadAI.MenuFlagWave 0`. **INCIDENT during this batch: edit_file corrupted SquadAIMainMenuHUD.cpp at a 16 KB boundary (bytes lost inside a Farsi TEXT literal). Recovered by re-cloning the repo baseline and re-applying ALL S16 edits via exact python string replacement. LESSON: never use edit_file on this 300 KB mixed-Farsi file — use python replacements with asserted anchors; always run a full-module UTF-8 decode check before zipping (now part of the audit).** |
| `S16-FLAG4` | user reports NO MENU shows up even after fixes (unverified, no log yet): waving-flag background is now a hard OPT-IN behind cvar `SquadAI.MenuFlagWave` (default 0 = EXACT pre-flag behaviour, material not even loaded). Enable with SquadAI.MenuFlagWave 1 once everything is stable. NOTE: if the menu is still missing with the cvar at 0 + /Game/SquadAI/MenuFlagWave deleted, the cause is NOT the flag work — get Saved/Logs/*.log |
| `S16-FLAG3` | menu went BLANK after user ran the STALE flag script (UI-domain material; Canvas DrawMaterial draws UI-domain as nothing): AutoResolve now accepts M_MenuFlagWave ONLY if Surface-domain (else warns `[SquadAIMenu] S16-FLAG3` and keeps static bg); ALSO repaired the texture-fallback chain that S16-FLAG2 accidentally spliced (else-if had rebound to the wrong if) |
| `S16-FLAG2` | user has NO widget — flag wave wired fully in code: ASquadAIMainMenuHUD gains FlagWaveBackgroundMaterial, auto-resolved from /Game/SquadAI/MenuFlagWave/M_MenuFlagWave in AutoResolveMissingTextures; DrawBackgroundMedia draws it via DrawMaterial through the SAME aspect-correct Ken-Burns crop/pan (AAA-MW-24 safe; AAA-MW-27 N/A — same clean key art). Fallback to static texture when material absent or bReducedMenuMotion. Material switched UI->Surface Unlit (+used_with_ui) because Canvas DrawMaterial needs Surface domain — MenuFlagWave zip script+README updated |
| `S16-FLAG` | menu-background flag wave: `SquadAI_MenuFlagWave.zip` — AI-matted flag mask (eroded around soldier + feathered), UI-domain material (2 layered traveling sine waves distort UV + 0.05 cloth shimmer, all masked), import script builds M_MenuFlagWave; user hooks it up via menu Image Brush->Image (one property, no widget rebuild) |
| `S15-TRENCH8` | env-art composition pass (researched: leveldesignbook clustering/gestalt, BeyondExtent ~70% negative space, repetition breakup): pass order now structure→anchors→loose props; firing steps + dugouts register ClusterAnchors, 60% of barrels/ammo cans gravitate to nearest anchor (vignettes); IsRestZone sine wave (45 m period, ~1/3 quiet) suppresses filler (stones/scorch/loose planks/stray barrels+cans); stones biased to floor edges (clean traversal line); stake heights/thickness randomized (silhouette breakup) with wire TopZ tracking; import script: PerInstanceRandom→Lerp(0.85,1.12)→Multiply BaseColor variation in all wood/metal/earth/canvas/corrugated/drum/ammocan/rug materials |
| `S15-TRENCH3` | camp-life layer + 2nd texture batch: NEW ScatterCampLife pass (one feature per ~18 m stretch — fire pits w/ stone rings, Persian prayer/rest rugs on NEW HISM_Rug, canvas stretchers, leaning assault ladders); 4 new material slots (Corrugated/Barrel/AmmoCan/Rug, fall back to MetalMaterial); 11 new textures (corrugated ridges, olive 55-gal drum, stenciled ammo can, full worn Persian carpet) + build_uv_pbr in import script; textures re-encoded (BC 2K jpg / N 1K png / R 1K jpg) to fit workspace cap; ALSO re-applied S15-PBR actor edits (ScorchMaterial slot, authored-material-wins) that were lost to the failed oversized snapshot |

### S12-INPUT — inventory/pause keys
Three compounding bugs: combat bridge ticked at **20 Hz** and edge-detected with
`IsInputKeyDown`, dropping any press under 50 ms; the HUD *draw* code read the
same keys again the same frame and cancelled the toggle; and `SetGamePaused`
stopped the bridge ticking (which is why a duplicate draw-side Esc handler
existed). Now: bridge ticks every frame, `bTickEvenWhenPaused = true`, is the
**single owner** of those keys, and early-returns from combat logic while paused.
Ammo top-up got its own 0.05 s accumulator to preserve its old rate.

### S14-INPUT — menus opened then closed after one frame (play-test of S12)
User play-tested S12-INPUT: both the inventory and the Esc menu **closed
immediately** after opening. The single-owner design was right; the edge
detector was wrong. `WasInputKeyJustPressed` reads `UPlayerInput` event counts
that are only rebuilt when the **PlayerController processes the input stack**.
Unpaused, the bridge is guaranteed to tick after the controller (component →
pawn → controller tick prerequisites). But both toggles call
`SetGamePaused(true)`, and on the **first paused frame the pawn does not tick**,
so the prerequisite chain is broken and the bridge (`bTickEvenWhenPaused`) can
tick *before* the controller's paused input pass — it re-read the previous
frame's still-uncleared Pressed event and toggled the menu straight back closed.
Fix (bridge only, `SquadAIPlayerCombatBridge.cpp/.h`): rising-edge detection on
`IsInputKeyDown` with prev-state flags (cannot double-fire off stale state; at
worst fires one frame late — safe now that the bridge ticks every frame), plus
a 0.2 s **real-time** debounce (`FPlatformTime::Seconds`, game clock is paused).
Lesson: `WasInputKeyJustPressed` is only single-frame-true if the caller is
guaranteed to run after the controller's input processing **every** frame —
which nothing with `bTickEvenWhenPaused` is.

### S14-AI — enemies charged the player and spammed grenades (play-test report)
User: "they go into attack mode and instead run to me and throw grenades at me,
a few crouch in attack mode tho." Two compounding causes, both in
`RunDirectCombatFallback` (`SoldierAIController.cpp`):
1. **The charge.** S13-AI's engagement hold (stop at 2200) lives in
   `STTask_EnemyMission` — but the direct-combat fallback had its own movement
   with `PreferredFireRange = 1500` for assault/loners and re-issued
   `MoveToActor(Threat, 1200)` every second. Two owners fought over movement
   and the MoveTo won: the mission task's `StopMovement()` was immediately
   overridden and enemies sprinted to ~12 m. The "few that crouch" were the
   fireteam suppress/flank roles (2800 hold) — the only ones exempt from the
   charge branch. Fix: the fallback now enforces the SAME 2200 hold line
   (constant kept equal to `EngageHoldRange` in STTask_EnemyMission — keep them
   in sync), stops path-following inside it, closes distance only beyond 2400,
   and roughly half the holders (pawn UniqueID parity) fight crouched. Cover-
   system poses (`bIsInCover`) are never touched.
2. **The grenades.** Frag gate was distance(800–2200) + 35%/s roll + only the
   component's 3 s cooldown → every closing enemy dumped both frags on contact.
   The code comment said "entrenched" but nothing measured it. Now a frag needs
   the threat to be actually entrenched (moved < 4 m across a 4 s sample),
   the 800–2200 band, a 10%/s roll, and ≥ 15 s since that soldier's previous AI
   throw of any type; smoke keeps its suppression trigger but shares the 15 s
   interval. State lives on the controller (S14-AI members in the header).

**Lesson:** movement must have exactly one owner per regime. Any new combat
code that calls MoveTo* must respect the 2200 engagement hold or it will
reintroduce the charge.

### S14-NAV — enemies frozen; user proved it despite the navmesh looking fine
`goalOnNavmesh=NO move=Failed` on all 263 log lines while goal RESOLUTION was
correct. Root cause candidates were split by S14-NAV (goal grounding: ±100 m
vertical projection + walk-back partial advance) and S14-NAVDIAG (runtime
navmesh census). **Outcome: enemies now march to the quest zone** — the
ungrounded raw `MissionZone->GetActorLocation()` fed to MoveToLocation was the
code-side fragility (user had insisted "the problem is in the code" — correct).

### S14-HIT — spawned enemies unhittable, placed ones fine (SOLVED, verify)
Placed enemy: red crosshair + killable. Pooled/wave enemy: neither. The only
path difference is `UEnemyPoolSubsystem::WakeEnemy`, which stamped the mesh
with the engine "CharacterMesh" preset — whose responses IGNORE ECC_Visibility
(BaseEngine.ini). Both the pack crosshair trace and the combat bridge damage
trace are visibility traces → every woken pawn was trace-transparent. Fix:
restore the mesh & capsule collision profiles from the component ARCHETYPE
(byte-for-byte what a placed instance has); never hardcode profiles on wake.
Also: wake refilled only the SquadAI UHealthComponent — recycled corpses kept
pack `BPC_HealthAI.currentHealth` at 0 (pack UI saw a dead target, pack damage
path early-outed). Wake now resets pack health + dead flags via the same
name-based reflection as the bridge. New cvar `SquadAI.DebugPlayerHits 1`
logs every combat trace hit + which damage path accepted/refused it.
**Lesson:** never stamp a generic collision profile onto pack-authored
components; restore from the archetype.

### S14-POOL — hostile counter climbs, map empty, clear-area quest never ends
Wave 1 (fresh prewarmed pawns) worked; every RECYCLED enemy after it was an
invisible walking capsule. HandleDeath ragdolls the mesh
(SetAllBodiesSimulatePhysics(true), transform trashed by physics), leaves a
death montage on the AnimInstance, stamps `bIsDead?`/`bIsDead` true on EVERY
component, destroys the controller, and sets LifeSpan(10). WakeEnemy only did
SetSimulatePhysics(false) — mesh stayed crumpled/detached, pack components
stayed "dead". Result: recycled enemies re-registered alive (HUD hostile count
kept climbing) but had no visible body, so the player could never kill them
and the clear-area quest could never complete. Fix (all in EnemyPool.cpp):
WakeEnemy now fully un-ragdolls (all bodies), re-attaches mesh to capsule,
restores the archetype relative transform, stops montages, clears
`bIsDead?`+`bIsDead` on ALL components, and cancels lifespan; SleepEnemy stops
ragdoll physics so pooled corpses don't simulate invisibly for the linger
window. **Lesson:** WakeEnemy must undo EVERYTHING HandleDeath does — keep the
two functions as mirror images when either changes.
**S14-POOL-B regression:** sleep-side `SetCollisionEnabled(NoCollision)` on the
mesh made enemies unhittable AGAIN — `SetCollisionProfileName` EARLY-OUTS when
the profile name is unchanged, so wake never re-applied the profile's enabled
state. Wake now calls `SetCollisionEnabled(archetype->GetCollisionEnabled())`
explicitly after the profile restore. **Lesson:** never rely on
SetCollisionProfileName to reset collision-enabled; it is a no-op if the name
matches the current profile.
**S14-POOL2:** un-ragdolling alone was not enough — recycled enemies were
STILL invisible because the PACK death sequence hides the mesh COMPONENTS
(SetActorHiddenInGame(false) does not undo component-level hiding), and pack
BPs own extra skeletal meshes (CharacterMesh0) that stay hidden+simulating.
WakeEnemy now mirrors CompleteRevive()'s proven restore: zero velocities,
sleep bodies, stop sim on all bodies, SetVisibility(true) +
SetHiddenInGame(false) on the main mesh AND every extra skeletal mesh
(sim/visibility only on extras — pack keeps attachment/collision/anim),
archetype relative transform with TeleportPhysics, AnimInstance->
InitializeAnimation() instead of StopAllMontages. **Lesson:** CompleteRevive
is the canonical corpse-to-combatant restore — WakeEnemy must stay in lockstep
with it (both undo HandleDeath + the pack death sequence).

### S14-STAB / S14-LEAD — post-pool-fix playtest fallout (4 issues, one batch)
1. "Invalid Bodies" ×N at PIE start: pool physics calls on meshes with no
   created bodies (prewarm sleeps) — guarded with `Bodies.Num() > 0`.
2. Injured allies FLOATING after explosions: CompleteRevive sets
   `SetEnableGravity(false)` on the mesh; a re-downed ally ragdolled with
   gravity off and drifted skyward. Gravity now force-enabled at every ragdoll
   start (EnterDownedState + both HandleDeath ragdoll paths). Additionally
   grenades no longer AddRadialImpulse to downed-but-alive soldiers (corpses
   still fly). **Lesson:** any SetEnableGravity(false) must be paired with a
   re-enable in every path that starts simulation again.
3. Leader stalled/cover-danced en route: `HasCombatThreat(0.55)` froze the
   march for ANY perceived contact — with waves continuously inbound there is
   always one. Combat hold now also requires the threat actor to be within
   StopForHostileRange (S14-LEAD).
4. Player got shredded even on Easy (all 3 waves are real now): Easy tuning
   softened — EnemyDamage_Easy 0.70→0.45, EnemyAccuracy_Easy 0.40→0.28. Both
   are Config properties (overridable in DefaultGame.ini SquadAITuning
   section). NOTE (map-side, not code): the log's "Mobility is Static"
   SetStaticMesh/AttachTo warnings come from DestroyedVillageCompoundActor's
   construction-time HISM setup — benign, but can be silenced by making the
   actor's SceneRoot/HISM components Static-consistent in the map.

### S14-COUNT — GhostCensus log (log2.txt) exonerated the pool, exposed books
User's log proved spawned enemies ARE visible/marching/killable (census
drained 15→0, registry correct) — but the HUD "remaining" count ROSE and the
Clear zone never completed. Cause: the wave spawner never removes dead
SquadAI enemies from `SpawnedEnemies`; when the pool recycles a corpse,
SleepEnemy resets its HealthComponent, so the 1.5 s CleanupDeadEnemies poll
counted the sleeper as ALIVE again → AliveEnemyCount climbed back after every
kill → `AliveEnemies<=0` unreachable. Fix: OnEnemyDied removes the corpse
from tracking immediately (pool owns it now); CleanupDeadEnemies additionally
drops hidden+collisionless sleepers.

### S14-END — post-campaign endless waves + GPU timeout crash
User: "after all missions are done, enemies spawn after a few seconds… then
the GPU crashed." Editor log (LogWindows...) showed a D3D12 GPU timeout
(payload >5 s, hung in UpdateAllPrimitiveSceneInfos) — the editor's own frame
starved while the standalone game ground the GPU. Gameplay cause:
ASpawnerTrigger activates its linked spawners on raw player overlap with no
mission-state awareness; the map contains a bLoopWaves=1 spawner, so stepping
on a trigger after the campaign finished re-armed INFINITE waves. Fix:
ActivateSpawner refuses when the map has MissionZones and ALL are Completed
(post-campaign peace). NOTE for the user: GPU-timeout risk is also reduced by
testing packaged/standalone builds with the editor CLOSED — two D3D12 clients
on one 8 GB card is exactly the starvation pattern in this log. **Lesson:** a pooled pawn must never be
tracked by TWO owners — the spawner's books must close at death, not at
destruction (pooled pawns are never destroyed). GhostCensus also showed a few
enemies loitering motionless 100–220 m out (stRunning=1, moveMode=1) — most
were engaging from range (40–80 m, inside vision), but far loiterers are a
possible follow-up (fireteam advance hold?). NavCensus healthy: 1 navdata,
Dynamic, 329k tiles.

### S15-TRENCH — trench-line dressing system
User: "create a system that adds more details besides crates and sandbags in
my trench lines" (screenshots: wide shallow desert trenches, sandbag parapets,
bare dirt floors). NEW actor `ATrenchDetailSplineActor`
(Public/Private `Environment/TrenchDetailSplineActor.*`, DisplayName "Trench
Detail Dresser"). Usage: drop in level, draw `DetailSpline` along the TRENCH
FLOOR, press **Build Details** (auto-rebuilds on edit while `bAutoRebuild`).
Ten toggleable categories, each one HISM (one draw call each): duckboard
walkway runs with gaps + loose planks, revetment plank panels leaning into the
walls with timber support posts, corrugated metal sheets, barrels (some
tipped), ammo-can clusters, barbed-wire pickets on BOTH parapet lips with two
sagging wire strands between stakes, tarp awnings, firing steps (with spent
brass scattered around them), stones and scorch patches. Every instance is
line-traced to the sculpted terrain (ECC_WorldStatic) so it hugs the trench
profile; layout is seeded (`Seed`, `DetailDensity` 0.25–2.0) with lateral
bands `FloorHalfWidth` / `WallOffset` / `ParapetOffset` to match the user's
wide trenches. Deliberately generates NO sandbags/crates — user has assets.
Defaults are engine basic shapes + palette-tinted DMIs (one per HISM, S8-MAT
scheme, same param-name candidates); 6 custom-mesh slots + 4 material slots
(Wood/Metal/Cloth/Ground) let real assets replace primitives without code.
All HISMs are `SetCanEverAffectNavigation(false)` and NoCollision except
barrels + firing steps (`bSolidProps`, BlockAllDynamic) — dressing can never
break trench navmesh or AI movement. Static-mobility safety: OnConstruction
returns immediately in game worlds (instances are serialized with the level),
so no runtime `SetStaticMesh` warnings à la the village HISMs.

### S15-PBR — photoreal trench materials (village-style tints rejected)
User: village textures "looked ugly", won't use the village system because of
it — wanted "beautiful PBR" for the trench dresser. Different pipeline this
time: photoreal AI-generated albedo sources (NOT procedural noise), made
seamless via half-offset + feathered center patch (verified 2x2 tile), 2K,
normal maps derived from height with wrapped edges, roughness derived per
family (metal: rust mask = rougher than remaining olive paint). Ships as
`SquadAI_TrenchMaterials.zip` (folder contains ONLY materials, per standing
rule): `Textures/` (13 PNGs) + `SquadAI_ImportTrenchMaterials.py` + README.
The import script (Tools > Execute Python Script) imports textures with
correct linear/normal settings and builds `M_TrenchWood/Metal/Earth/Canvas`
using the engine `WorldAlignedTexture`/`WorldAlignedNormal` functions —
triplanar, so scaled-primitive props show no UV stretching — with automatic
plain-UV fallback if pin names ever fail, plus `M_TrenchScorch` (translucent
two-sided ragged-alpha burn decal). Actor changes (small): new
`ScorchMaterial` slot (HISM_Scorch uses it, falls back to GroundMaterial);
`ConfigureHISM` no longer layers palette tint over an authored material —
tint applies ONLY to the engine-primitive fallback. User assigns 5 material
slots once per dresser actor (table in the zip README). Generation sources
kept in `art/trench_pbr/`, pipeline script `art/tools/make_trench_pbr.py`
(sandbox-side; user never runs it). NOTE: `art/trench_pbr/` sources and
`T_Village_WoodBeam_2K.zip` were later deleted for workspace-size reasons
(S15-TRENCH2 cleanup); the baked textures live on inside
`SquadAI_TrenchMaterials.zip`, which is the only copy — don't delete it.

**S15-TRENCH2 (pre-compile realism pass, user asked to "work on it
furthermore"):** duckboard slabs → 4 individual planks with missing-plank
gaps and Z jitter; corrugated panels get 5 half-embedded square ribs (same
HISM, cube mesh) faking the corrugation profile; firing steps get a wooden
tread plank on top; tarps rebuilt as pitched two-panel awnings (ridge-tent
silhouette, undersides added, 2 traced tie posts via HISM_Post); parapet
wire now 3 strands at 30 cm spacing; casings pass nullptr material so they
stay brass-tinted even when MetalMaterial is assigned; NEW pass
`ScatterOverheadCover` (bOverheadCover, every ~15 m, 30%·density): traces
both berm tops, lays 6 cross-planks berm-to-berm (reuses HISM_Duckboard) +
a skewed corrugated sheet on top, shell-gap chance per plank; NEW pass
`ScatterCommWire` (bCommWire): field-telephone poles every 12 m on ONE
seed-chosen side at ParapetOffset+70, 2.6 m tall, with a 3-segment
catenary-sagging wire between consecutive pole tops (skips gaps >16 m or
failed traces). All new geometry reuses the existing 13 HISMs — no new
components, no new draw calls.

**S15-TRENCH3 (camp-life + texture batch 2).** WARNING learned the hard way:
the S15-PBR actor edits (ScorchMaterial slot, ConfigureHISM
authored-material-wins if/else) were silently LOST when that turn's snapshot
blew the ~128 MB workspace cap — always `du -sh` before ending a turn with
big binaries, and re-verify old markers after any size incident. They are
re-applied under S15-TRENCH3. New content: `ScatterCampLife` pass — every
~18 m picks at most ONE of: fire pit (1.35x scorch + ring of 8 traced
stones), prayer rug (NEW `HISM_Rug` plane, RugMaterial/M_TrenchRug = one
full worn Persian carpet per plane, long axis along trench, near-wall),
stretcher (2 lying poles + canvas via HISM_Post/HISM_Tarp), assault ladder
(2 rails + 6 rungs via HISM_Post, leaning 14–20° into the wall) — toggles
bFirePits/bPrayerRugs/bStretchers/bLadders. Dedicated prop materials:
CorrugatedMaterial/BarrelMaterial/AmmoCanMaterial slots (fallback
MetalMaterial) so sheets get real ridge normals, barrels get the olive drum
wrap, cans get stenciled steel; import script gained `build_uv_pbr`
(plain-UV materials where UV orientation matters: ridges, drum bands, rug).
Texture sizes: BC = 2K jpg q92, N = 1K png, R = 1K jpg (147 MB folder was
unshippable; now 26 MB). `art/trench_pbr2/` sources deleted after baking;
`SquadAI_TrenchMaterials.zip` remains the ONLY copy of all 24 textures.

### S12-DOWN — downed ally (v1 was reverted, read this)
`EnterDownedState` ragdolls the mesh, which then moves in **world space** and
stops following the capsule, so `GetActorLocation()` (used by the revive prompt
and its 220 cm range) stayed where the soldier was standing.

- **v1 (BAD, reverted):** dragged the capsule onto the ragdoll every frame with
  `SetActorLocation` + `SetWorldTransform`. This fought the physics solver and
  made injured allies **vanish**. Never move a physics actor to fix a UI bug.
- **v2 (current):** `ASoldierCharacter::GetBodyLocation()` — a pure query
  returning the pelvis bone while ragdolling, with a 15 m sanity clamp. Moves
  nothing. HUD uses it for both prompt position and range.

### S13-AI — enemies charged instead of shooting
Caused by `S11-AI`. Before it, enemies with no MissionZone had no goal, stood
still, and the combat states ran by accident. Once they always had a goal the
move request was re-issued every repath, so the pawn never left path-following
and never entered the aim pose. Fix: **engagement hold** — inside 2200 cm of a
threat, stop movement and return, letting aim/fire states run. Acceptance radius
when the goal *is* a threat raised 300 → 1800 cm.

### S13-FX — mortar danger zone
Canvas `DrawLine` can only make flat, unshaded, constant-width screen-space
polylines; stacking concentric ones read as a **contour map**. Replaced with a
projected ground **decal** (`M_MortarDangerDecal`, built by the importer from
pure math nodes — no textures, no engine material functions). C++
`AQuestNativeHUD::EnsureMortarDecal` spawns it and drives `Urgency`, `Opacity`,
`TimeRemaining`, `DangerColor`; the component is destroyed on expiry. Falls back
to **one** soft ring if the material is missing.

### S13-GEO — lego effect / roof holes / floating bases
- `LenScale` was `FRandRange(0.97, 1.0)` — every block **shrunk** up to 3% of its
  bay, so adjacent bays never touched → a hard seam at every boundary. Now
  `1.02–1.06` (overlap hidden inside the neighbour). Course overlap 1.02 → 1.10.
  Out-of-plane jitter halved.
- One roof path spawned slabs at **0.92 of their cell** — always left holes.
  Now 1.10. Main path 1.02 → 1.12, tilt jitter 1.6° → 0.7° (on a 2 m tile a 1.6°
  lean shifts an edge ~5 cm and ate the whole overlap).
- New `GroundEmbedDepth` (default 45 cm) drives the bottom course into terrain.

---

## 6. Current state / open items  (updated 2026-09-29, S16-FLAG shipped)

### THE single most important fact
**The user has NOT compiled since before `S15-TRENCH` existed.** His words:
last compile predates the "add more details to my trenches" request. Therefore
the ENTIRE trench line (`S15-TRENCH` .. `S15-TRENCH8`) plus any late-S14 zip
he skipped is code that has NEVER been through his compiler. Expect the first
compile to be the next big event; be ready to fix errors fast. Everything was
balance-checked and scanned for C4189 (unused locals) on delivery, but that is
not a compile.

### Confirmed working (play-tested by user)
- `S11-HUD` weapon plate.
- S14-era fixes verified through his logs up to ~`S14-COUNT`/`S14-GHOST`
  (log2.txt / log123.txt era). `S14-LEAD` retest still unconfirmed.

### Delivered, awaiting user action (in order)
1. **Compile** the current `SquadAI_Setup_And_Code.zip` (S15-TRENCH..TRENCH8 + S14-END).
2. **Run** `SquadAI_ImportTrenchMaterials.py` (from SquadAI_TrenchMaterials.zip)
   -> 25 textures + 10 materials in `/Game/SquadAI/TrenchMaterials`.
3. **Place** a "Trench Detail Dresser", assign the 10 material slots
   (Wood/Metal/Cloth/Ground/Scorch/Corrugated/Barrel/AmmoCan/Rug/Netting ->
   M_Trench* of the same name), draw DetailSpline along the trench floor.
   His trenches are WIDE: suggest FloorHalfWidth 350-450, WallOffset 450-550,
   ParapetOffset 650-800 (defaults 250/320/480). Success check: Output Log
   prints `[TrenchDresser] ...: built N instances in K/17 categories...`.
4. **Run** `SquadAI_ImportMenuFlagWave.py` (S16-FLAG/S16-FLAG2). NO widget
   work: the code menu auto-detects M_MenuFlagWave and draws it (flag waves,
   soldier still, same Ken-Burns crop). Needs the S16-FLAG2 code compiled.
   If a static sliver of flag shows near the soldier's right shoulder, widen
   the mask there (offer made).

### Open — gameplay
1. **Far loiterers**: enemies idling at 100-220 m remain unexplained
   (40-80 m "stuck" enemies were re-diagnosed as normal ranged engagement).
   Standing offer to the user: raise enemy vision range (~90 m currently).
2. `S14-LEAD` retest (leader no longer stalling on distant contacts).
3. Old navmesh saga (below) believed resolved by S14-NAV grounding; the next
   `grounded=` log line decides. Kept for reference:

### Navmesh history (reference)
`SquadAI.DebugEnemyGoals 1` once showed 263/263 `move=Failed goalOnNavmesh=NO`
with engine warnings `Recreating dtNavMesh instance due mismatch in serialized
maxTiles` and `NavData RegistrationFailed_AgentAlreadySupported` (duplicate
RecastNavMesh actors). Editor-side fix given (delete extra RecastNavMesh,
bounds over battlefield, Build Paths). Code-side `S14-NAV` additionally grounds
mission-zone goals (±100 m projection + walk-back). grounded=YES in the next
log => floating marker was the cause; grounded=NO => genuine navmesh absence.

### Shelved tracks (do not revive without the user asking)
- **Village system + Blender module plan** — user rejected the village art
  ("lego effect", ugly procedural textures) and says he won't use the village
  system. The Blender drop-in-cube plan in older revisions is dead unless he
  reopens it.
- **Sandbags** (he has his own assets — the trench dresser deliberately adds
  OTHER prop types), **leader character-swap** (shelved).

---

## 7. Lessons — do not repeat these

Full detail in `SquadAI_Setup/MATERIAL_RECORDS.md` (9 numbered lessons). Summary:

**Texture authoring**
1. Measure normals in **packed** space (`nz*0.5+0.5`).
2. Never `T.nrm()` a Worley distance you intend to threshold — it rescales
   globally and the falloff stops matching the cell boundary (round blobs).
3. Never drive colour with the hash that drives **presence** — on an existing
   chunk it only spans `0..coverage`, so everything lands at one end and
   variant tests like `id > 0.8` can never fire.
4. `T.srgb_noise` returns `1.0 ± amt` — a **multiplier**. Adding it clips the
   albedo to solid white (shows up as a ~1.5 KB BC file).
5. Calibrate strength off the **saved height map**, ~50× faster than re-rendering.
6. Detail-normal strength scales **inversely** with base relief. A flat road with
   a wall-strength DN becomes dark grit speckle.
7. **Measure before believing a visual diagnosis.** A "diagonal grain" survived
   warping, multi-seeding and a 4× resolution change; an FFT then showed the
   noise was isotropic. Three renders wasted chasing a ghost.
8. Never derive stripes from `noise % 1.0` — that is the **contour lines** of the
   field, i.e. a maze/coral pattern. Drive directional features by the
   across-feature coordinate.
9. A ramp displacement must be **a fraction of one period** (`*6.0` let bands
   slide past each other and re-form along the contours — the maze came back).

**Engine / code**
- `connect_material_expressions` fails **silently**; UE `If` node inputs are
  named `A > B`, not `AGreaterThanB`. Prefer branchless math; always verify.
- A material that fails to compile silently falls back to the default grey
  checker — that is what black/checkerboard geometry means.
- Don't move a physics actor to fix a UI problem (S12-DOWN v1).
- Canvas lines can never look 3D. Use decals/meshes.
- `STTask_EnemyMission::Tick` seeds `GoalLoc` from `GetEffectiveMoveGoal()`
  **before** all fallbacks, and every fallback is gated on
  `GoalLoc.IsNearlyZero()`. A non-zero registry goal silently bypasses them.
- Enemies are **never** pushed goals: `UQuestObjective_AutoZone::OnStart` pushes
  move commands to **team 0 only**.
- An uploaded file named `Compile ... .txt` may be an **editor run log**, not a
  build log. The user has twice appended their prompt to the **end** of it —
  always read the tail.

**Workspace / delivery**
- Snapshot size cap (~128 MB) can silently drop files AND revert source edits.
  Keep zip XOR folder; `du -sh` before ending big-binary turns; re-grep markers
  after any incident.
- UE builds treat **C4189 (unused local) as an error**. Before shipping, scan
  new cpp code for locals that are declared-then-unused (this bit once; caught
  again by scan in S15-TRENCH7).
- `edit_file` with reconstructed old_text fails — always bash-read the current
  block first.
- Balance-check every shipped .h/.cpp: `python3 -c "s=open(f).read(); print(s.count('{')-s.count('}'), s.count('(')-s.count(')'))"` must print `0 0`.
- generate_image can return an empty result — retry with a reworded prompt.
- Grep uploaded logs for everything needed BEFORE deleting them.

---

## 8. Suggested next steps

1. **Get the user to compile** the current code zip — the whole S15 trench line
   is uncompiled. If errors: fix in one small batch, rebuild zip, re-download.
2. Walk him through the trench install (see §6 checklist) and ask for
   screenshots + the `[TrenchDresser]` stats line + width tuning feedback.
3. Hook up S16-FLAG (menu brush swap) — zero risk, instant visual win.
4. After trench screenshots: iterate on whatever looks off (widths, density,
   category toggles) — polish means improving EXISTING features, not new
   categories (user directive, S15-TRENCH7).
5. Then the gameplay backlog: far loiterers (100-220 m), vision-range offer,
   S14-LEAD retest confirmation.
6. Keep asking permission per batch, keep batches small, keep replies brief.
