"""T_Village_MudbrickWall — KAHGEL (mud+straw plaster) over adobe brick.

Khuzestan / Dehlavieh reference, NOT Arabian/Gulf. The wall a soldier actually
sees is kahgel: warm red-ochre mud-and-straw render, hand-smoothed, lumpy, with
broad shrinkage cracks and straw showing through. The brick courses beneath are
only exposed where the kahgel has spalled away - roughly a quarter of the wall.

An earlier version had this inverted (neat pale grey-beige exposed brick grid
with small plaster patches), which is why it read as cartoonish and wrong."""
import gc, sys, numpy as np
sys.path.insert(0, '/home/user/art/tools')
import texlib as T

def build(res=2048, seed=1201):
    rng = np.random.default_rng(seed)
    S = res / 2048.0

    # ---------------- brick courses (running bond, hand-made irregularity)
    rows = 16                      # courses across the tile
    cols = 7                       # bricks per course
    c = np.linspace(0, 1, res, endpoint=False, dtype=np.float32)
    gy, gx = np.meshgrid(c, c, indexing='ij')

    # wobble the coursing so rows are not machine-straight
    wob = T.fbm(res, 4, 5, seed=seed + 1) - 0.5
    ry = gy + wob * (0.9 / rows)
    row_f = ry * rows
    row_i = np.floor(row_f).astype(np.int32) % rows        # WRAP: modulo course count
    row_t = row_f - np.floor(row_f)

    # half-brick offset on alternate courses + per-row random shift.
    # row_i is already modulo'd, so course 0 and course `rows` hash identically
    # and the tile wraps cleanly top-to-bottom.
    shift = (row_i % 2) * 0.5 + T.hash01(row_i, salt=7) * 0.12
    colwob = T.fbm(res, 5, 5, seed=seed + 2) - 0.5
    cxf = (gx + shift + colwob * (0.5 / cols)) * cols
    col_i = np.floor(cxf).astype(np.int32) % cols          # WRAP: modulo brick count
    col_t = cxf - np.floor(cxf)

    brand = T.hash01(row_i * 131 + col_i * 37, salt=3)     # per-brick random
    del wob, ry, row_f, shift, colwob, cxf

    # mortar gap: distance to nearest brick edge, in both axes
    mort_w_y, mort_w_x = 0.085, 0.055
    ey = np.minimum(row_t, 1 - row_t)
    ex = np.minimum(col_t, 1 - col_t)
    edge = np.minimum(ey / mort_w_y, ex / mort_w_x)
    # Hand-made adobe has ragged, chipped arrises - perturb the edge distance
    # with noise so no two bricks share the same outline.
    chip = (T.fbm(res, 34, 5, seed=seed + 32) - 0.5) * 0.85
    chip += (T.worley(res, 60, seed=seed + 33, kind='F1') - 0.5) * 0.45
    edge = np.clip(edge + chip, 0, None)
    brick_mask = T.sstep(edge, 0.12, 0.95)            # 1 = brick face, 0 = mortar
    # knock the corners off a subset of bricks entirely
    broken = T.sstep(T.hash01(row_i * 29 + col_i * 53, salt=17), 0.80, 1.0)
    brick_mask *= 1 - broken * T.sstep(1 - edge, 0.55, 1.0) * 0.55
    del ey, ex, edge, chip, broken

    # ---------------- heightfield
    h = np.zeros((res, res), np.float32)
    h += brick_mask * (0.55 + brand * 0.22)           # bricks proud of mortar
    # each brick slightly domed + individually tilted
    dome = (1 - (2 * col_t - 1) ** 2) * (1 - (2 * row_t - 1) ** 2)
    h += brick_mask * dome * 0.035   # subtle crown only - strong dome = pillows
    h += brick_mask * ((brand - 0.5) * 0.06)
    del dome

    # coarse clay grain + straw temper inside the bricks
    grain = T.fbm(res, 8, 8, seed=seed + 3)
    h += (grain - 0.5) * 0.19 * brick_mask
    grit = T.fbm(res, 55, 4, seed=seed + 31)
    h += (grit - 0.5) * 0.070 * brick_mask      # coarse sand temper
    straw = T.fbm(res, 24, 4, seed=seed + 4, ridged=True)
    straw_m = T.sstep(straw, 0.72, 0.95)
    h += straw_m * 0.035 * brick_mask

    # mortar is rough, pitted lime-mud
    mgrain = T.fbm(res, 30, 6, seed=seed + 5)
    h += (1 - brick_mask) * (mgrain * 0.10 - 0.03)
    del mgrain, grit, straw

    # ---------------- plaster skin over the top, spalling away
    pl_big = T.fbm(res, 6, 5, seed=seed + 6)
    pl_warp_x = T.fbm(res, 4, 4, seed=seed + 7)
    pl_warp_y = T.fbm(res, 4, 4, seed=seed + 8)
    pl = T.warp(pl_big, pl_warp_x, pl_warp_y, 45 * S)
    plaster = T.sstep(pl, 0.26, 0.44)                 # 1 = kahgel remains (~75% cover)
    # ragged torn edge
    tear = T.fbm(res, 22, 6, seed=seed + 9) * 0.7 + T.fbm(res, 9, 4, seed=seed + 19) * 0.3
    plaster = np.clip(plaster + (tear - 0.5) * 0.40, 0, 1)
    plaster = T.sstep(plaster, 0.28, 0.62)
    plaster = T.blur(plaster, 1.2 * S)

    pl_surf = T.blur(T.fbm(res, 10, 7, seed=seed + 10), 1.0 * S)
    h_plaster = 0.62 + pl_surf * 0.12                 # plaster sits above brick
    # Torn plaster is a SHEET with thickness: hard step at the tear line, plus a
    # thin crumbling lip just inside the edge and a dirt undercut just outside.
    edge_band = plaster * (1.0 - plaster) * 4.0       # peaks on the tear contour
    inner_lip = T.sstep(plaster, 0.55, 0.85) * T.sstep(edge_band, 0.25, 0.85)
    h = T.mix(h, h_plaster, T.sstep(plaster, 0.18, 0.58) * 0.985)
    h += inner_lip * 0.045                            # raised crumbling rim
    h -= T.sstep(edge_band, 0.35, 1.0) * (1 - plaster) * 0.05   # undercut shadow
    del pl_big, pl_warp_x, pl_warp_y, pl, tear, pl_surf, h_plaster, edge_band

    # Kahgel is applied by hand and floated flat with a wooden trowel, so it is
    # LUMPY at a broad scale rather than grainy: long soft swells and hollows,
    # plus the shallow arcs left by the plasterer's hand.
    lump  = (T.fbm(res, 7,  4, seed=seed + 40) - 0.5) * 0.185
    lump += (T.fbm(res, 15, 3, seed=seed + 41) - 0.5) * 0.026
    trowel = (T.fbm(res, 26, 2, seed=seed + 42) - 0.5) * 0.038
    h += (lump + trowel) * plaster

    # Broad shrinkage cracking: mud-straw render dries and crazes into wide,
    # shallow polygons. These are much broader than the hairline brick cracks
    # and live ONLY in the kahgel.
    shr = T.worley(res, 26, seed=seed + 43, kind='F2F1')
    shr_w = T.warp(shr, T.fbm(res, 9, 4, seed=seed + 44),
                        T.fbm(res, 9, 4, seed=seed + 45), 26 * S)
    shrink = T.sstep(1 - shr_w, 0.86, 1.0) * plaster
    shrink *= T.sstep(T.fbm(res, 5, 4, seed=seed + 46), 0.35, 0.75)   # not everywhere
    h -= shrink * 0.055
    del lump, trowel, shr, shr_w

    # ---------------- damage: bullet pocks, impact craters, erosion runnels
    # Small-arms strikes. A raw Worley F1 gives an obvious regular grid of round
    # dots, so: domain-warp it (breaks circularity), gate it behind a low-freq
    # cluster mask (bursts hit in groups, most of the wall is untouched) and add
    # a spall rim so each strike reads as knocked-out material, not a drilled hole.
    pw_x = T.fbm(res, 10, 5, seed=seed + 20)
    pw_y = T.fbm(res, 10, 5, seed=seed + 21)
    pock = T.warp(T.worley(res, 26, seed=seed + 11, kind='F1'), pw_x, pw_y, 22 * S)
    cluster = T.sstep(T.fbm(res, 3, 4, seed=seed + 22), 0.52, 0.78)
    strike = T.sstep(1 - pock, 0.86, 1.0) * cluster
    spall = T.sstep(1 - pock, 0.70, 0.86) * cluster
    pock_m = np.clip(strike + spall * 0.45, 0, 1)
    h -= strike * 0.20
    h -= spall * 0.055                                # shallow chipped halo
    h += T.sstep(1 - pock, 0.62, 0.70) * cluster * 0.018   # pushed-up lip
    del pw_x, pw_y, pock, cluster

    # Shell / RPG craters: fewer, larger, with a blown-out rim.
    cw_x = T.fbm(res, 5, 4, seed=seed + 23)
    cw_y = T.fbm(res, 5, 4, seed=seed + 24)
    crater = T.warp(T.worley(res, 6, seed=seed + 12, kind='F1'), cw_x, cw_y, 55 * S)
    crater_m = T.sstep(1 - crater, 0.82, 1.0)
    h -= crater_m * 0.30
    h += T.sstep(1 - crater, 0.66, 0.82) * 0.05
    del cw_x, cw_y, crater

    # Hairline settlement cracks - thin and branching, NOT a thick mud-flat web.
    ck = T.worley(res, 9, seed=seed + 25, kind='F2F1')
    ck = T.warp(ck, T.fbm(res, 8, 4, seed=seed + 26), T.fbm(res, 8, 4, seed=seed + 27), 18 * S)
    crack = T.sstep(1 - ck, 0.975, 1.0)               # very narrow hairline
    # Only a few regions of the wall have settled enough to crack at all...
    crack *= T.sstep(T.fbm(res, 3, 4, seed=seed + 28), 0.62, 0.86)
    # ...and cracks prefer the weak mortar joints, only occasionally crossing a
    # brick face. Without this they read as a mud-flat web laid over everything.
    crack *= (1 - brick_mask * 0.80)
    h -= crack * 0.040
    del ck

    # rain runnels streaking down the wall
    run = T.fbm(res, 40, 3, seed=seed + 13)
    run = T.blur(run, (0.6 * S, 26 * S))              # stretch vertically
    run_m = T.sstep(T.nrm(run), 0.60, 0.95)
    h -= run_m * 0.05
    del run

    # Erosion is a MACRO process: run it on the large forms only, then re-add the
    # high-frequency surface afterwards. Eroding the detailed field (as an
    # earlier revision did) smears the clay grain away and leaves smooth pillows.
    h = T.nrm(h)
    h_macro = T.blur(h, 3.0 * S)
    h_fine = h - h_macro                                # keep the crisp detail
    h_macro = T.erode(h_macro, iters=14, rate=0.16)
    h = T.nrm(h_macro + h_fine * 1.35)
    del h_macro, h_fine

    # Micro relief that survives all the way to the normal map: clay tooth,
    # sand temper and tiny pits. Bricks get more of it than plaster.
    micro = (T.fbm(res, 90, 4, seed=seed + 34) - 0.5) * 0.013
    micro += (T.worley(res, 130, seed=seed + 35, kind='F1') - 0.5) * 0.005
    micro += (T.fbm(res, 190, 3, seed=seed + 36) - 0.5) * 0.007
    # Kahgel's own fine surface: chopped-straw impressions (elongated) and grit,
    # gated by a low-frequency mask so the density VARIES across the wall instead
    # of reading as uniform sandpaper.
    kvar = T.sstep(T.fbm(res, 4, 4, seed=seed + 49), 0.25, 0.85)
    kstraw = (T.blur(T.fbm(res, 120, 2, seed=seed + 50) - 0.5, (0.6 * S, 3.2 * S))) * 0.026
    kgrit  = (T.worley(res, 200, seed=seed + 51, kind='F1') - 0.5) * 0.004
    kfine  = (kstraw + kgrit) * (0.35 + 0.65 * kvar)
    h = h + kfine * plaster
    h = h + micro * (0.25 + 0.75 * (1 - plaster))
    del kvar, kstraw, kgrit, kfine
    h = T.nrm(h)
    del micro

    ao = T.ao_from_height(h, radius=30 * S, strength=0.85)
    ao = np.clip(ao * 0.88 + 0.12, 0, 1)   # lift the floor: joints were crushing to black

    # ---------------- albedo (Dehloran gypsum-marl palette, linear-ish sRGB)
    # Khuzestan kahgel palette: warm red-ochre earth, NOT pale grey gypsum.
    brick_a = np.array([0.353, 0.235, 0.169], np.float32)   # shaded exposed brick
    brick_b = np.array([0.506, 0.361, 0.251], np.float32)   # sunlit exposed brick
    mortar_c = np.array([0.427, 0.325, 0.235], np.float32)  # mud mortar
    plaster_a = np.array([0.400, 0.251, 0.161], np.float32) # kahgel, damp/shaded
    plaster_b = np.array([0.612, 0.435, 0.290], np.float32) # kahgel, sun-faded

    alb = np.zeros((res, res, 3), np.float32)
    # Wider per-brick tonal spread + a few strongly off-tone bricks (reclaimed
    # or differently-fired), which is what stops adobe reading as flat paint.
    oddball = T.hash01(row_i * 71 + col_i * 17, salt=11)
    bt = np.clip(brand * 1.25 - 0.12 + (grain - 0.5) * 0.55, 0, 1)
    bt = np.clip(bt + T.sstep(oddball, 0.88, 1.0) * 0.45
                    - T.sstep(1 - oddball, 0.90, 1.0) * 0.35, 0, 1)[..., None]
    alb = brick_a * (1 - bt) + brick_b * bt
    alb = T.mix(alb, mortar_c[None, None, :] * np.ones_like(alb), 1 - brick_mask)

    pt = T.nrm(T.fbm(res, 6, 6, seed=seed + 14))[..., None]
    pcol = plaster_a * (1 - pt) + plaster_b * pt
    alb = T.mix(alb, pcol, plaster[..., None] * 0.97)

    # straw flecks, dust film, dirt in the cavities
    alb *= (1 - straw_m * 0.18)[..., None]
    alb += (straw_m * (0.35 + 0.65 * plaster))[..., None] * np.array([0.16, 0.13, 0.07], np.float32)
    dust = T.nrm(T.fbm(res, 5, 5, seed=seed + 15))[..., None]
    alb = T.mix(alb, np.array([0.639, 0.525, 0.376], np.float32) * np.ones_like(alb), dust * 0.14)
    zone = T.nrm(T.fbm(res, 3, 5, seed=seed + 47))
    zone2 = T.nrm(T.fbm(res, 6, 4, seed=seed + 48))
    alb *= (0.80 + 0.40 * zone)[..., None]                # broad light/dark drift
    alb = T.mix(alb, np.array([0.494, 0.353, 0.239], np.float32) * np.ones_like(alb),
                (T.sstep(zone2, 0.62, 1.0) * 0.30)[..., None])   # damp/shaded patches
    alb *= (0.55 + 0.45 * ao)[..., None]                  # dirt darkens cavities
    alb *= (1 - run_m * 0.22)[..., None]                  # water staining
    alb *= (1 - pock_m * 0.10)[..., None]
    # fresh un-weathered brick exposed inside craters
    alb = T.mix(alb, np.array([0.396, 0.267, 0.188], np.float32) * np.ones_like(alb), crater_m[..., None] * 0.55)
    # Fresh pale gypsum dust exposed by small-arms strikes, dark line in cracks,
    # and a bright raw edge where the plaster sheet has torn away.
    alb = T.mix(alb, np.array([0.678, 0.569, 0.416], np.float32) * np.ones_like(alb),
                (strike * 0.62)[..., None])
    alb *= (1 - crack * 0.42)[..., None]
    alb *= (1 - shrink * 0.30)[..., None]        # kahgel shrinkage crazing
    alb = T.mix(alb, np.array([0.643, 0.518, 0.369], np.float32) * np.ones_like(alb),
                (inner_lip * 0.30)[..., None])
    # Dust settles on every up-facing ledge (brick tops, plaster lips).
    ledge = np.clip(T.blur(h, 2.0 * S) - T.blur(h, 9.0 * S), 0, 1)
    alb = T.mix(alb, np.array([0.659, 0.549, 0.396], np.float32) * np.ones_like(alb),
                T.nrm(ledge)[..., None] * 0.18)
    alb *= T.srgb_noise((res, res, 1), rng, 0.05)
    alb = np.clip(alb, 0, 1)
    del bt, pt, pcol, dust, ledge, grain, brand, row_i, col_i, oddball, zone, zone2

    # ---------------- roughness / metallic / AO -> ORM
    rough = np.full((res, res), 0.86, np.float32)
    rough -= plaster * 0.06                    # plaster slightly smoother
    rough += (1 - brick_mask) * 0.05           # mortar rougher
    rough += shrink * 0.05
    rough += straw_m * 0.05
    rough -= run_m * 0.12                      # water-polished streaks
    rough += crater_m * 0.04
    rough += strike * 0.07                     # pulverised gypsum is very matt
    rough += crack * 0.05
    rough += (T.fbm(res, 12, 5, seed=seed + 16) - 0.5) * 0.10
    rough += (T.fbm(res, 46, 4, seed=seed + 29) - 0.5) * 0.05   # fine breakup
    rough = np.clip(rough, 0.35, 1.0)
    metal = np.zeros((res, res), np.float32)
    del strike, spall, crack, crater_m, pock_m, run_m, straw_m, inner_lip, shrink

    nrmmap = T.to_dx(T.normal_from_height(h, strength=2.0, res_scale=S))
    # detail normal: fine clay tooth, tiles 8x over the surface
    # Detail normal, intended to tile ~8x on top of the base normal: micro clay
    # tooth + sand grit + tiny straw pits. This is what holds up at 1m viewing.
    # Kahgel tooth: chopped straw fibres and fine sand. The old recipe leaned on
    # worley F1, whose rounded cells read as blobby popcorn rather than render.
    dh = (T.fbm(res, 72, 5, seed=seed + 17) * 0.34
          + T.blur(T.fbm(res, 140, 3, seed=seed + 18) - 0.5,
                   (0.5 * S, 2.6 * S)) * 0.34            # straw, directional
          + T.worley(res, 110, seed=seed + 52, kind='F1') * 0.10   # a little grit
          + T.fbm(res, 150, 3, seed=seed + 30) * 0.22)
    dn = T.to_dx(T.normal_from_height(T.nrm(dh), strength=0.9, res_scale=S))
    del dh

    orm = np.stack([ao, rough, metal], -1)
    del ao, rough, metal, plaster, brick_mask
    gc.collect()
    return dict(albedo=alb, normal=nrmmap, detail_normal=dn, height=h, orm=orm)
