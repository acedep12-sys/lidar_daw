"""
texlib.py — tileable procedural PBR texture library (Dehloran / Ilam palette).
Pure numpy+scipy. Every generator is seamlessly tileable: all noise uses a
periodic integer lattice, all blurs use mode='wrap'.
"""
import numpy as np
from scipy import ndimage

# ---------------------------------------------------------------- core noise
def _lattice(res, period, rng):
    """Random periodic lattice, bilinearly interpolated to res x res."""
    g = rng.random((period, period)).astype(np.float32)
    # tile one extra row/col so interpolation wraps
    gg = np.pad(g, ((0, 1), (0, 1)), mode='wrap')
    y = np.linspace(0, period, res, endpoint=False, dtype=np.float32)
    x = np.linspace(0, period, res, endpoint=False, dtype=np.float32)
    yi = np.floor(y).astype(np.int32); xi = np.floor(x).astype(np.int32)
    yf = (y - yi)[:, None]; xf = (x - xi)[None, :]
    # smoothstep for perlin-ish feel
    yf = yf * yf * (3 - 2 * yf); xf = xf * xf * (3 - 2 * xf)
    v00 = gg[np.ix_(yi, xi)]; v01 = gg[np.ix_(yi, xi + 1)]
    v10 = gg[np.ix_(yi + 1, xi)]; v11 = gg[np.ix_(yi + 1, xi + 1)]
    return (v00 * (1 - yf) * (1 - xf) + v01 * (1 - yf) * xf +
            v10 * yf * (1 - xf) + v11 * yf * xf)

def fbm(res, base=4, octaves=8, gain=0.5, lac=2, seed=0, ridged=False):
    rng = np.random.default_rng(seed)
    out = np.zeros((res, res), np.float32); amp = 1.0; tot = 0.0; p = base
    for _ in range(octaves):
        if p >= res: break
        n = _lattice(res, int(p), rng)
        if ridged:
            n = 1.0 - np.abs(n * 2 - 1)
            n *= n
        out += n * amp; tot += amp
        amp *= gain; p = int(p * lac)
    return out / max(tot, 1e-6)

def worley(res, cells=16, seed=0, kind='F1'):
    """Tileable Worley/cellular noise. Vectorised: instead of testing every
    feature point against every pixel, each pixel only examines the 3x3 block
    of cells around it, with wrapped cell indices. O(res^2 * 9)."""
    rng = np.random.default_rng(seed)
    jitter = rng.random((cells, cells, 2)).astype(np.float32)

    c = np.linspace(0, 1, res, endpoint=False, dtype=np.float32) * cells
    gy, gx = np.meshgrid(c, c, indexing='ij')
    cy = np.floor(gy).astype(np.int32)
    cx = np.floor(gx).astype(np.int32)

    best1 = np.full((res, res), 1e9, np.float32)
    best2 = np.full((res, res), 1e9, np.float32)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            ny = (cy + dy) % cells
            nx = (cx + dx) % cells
            # feature point position in continuous cell space (wrap-aware)
            fy = (cy + dy) + jitter[ny, nx, 0]
            fx = (cx + dx) + jitter[ny, nx, 1]
            d = np.sqrt((gy - fy) ** 2 + (gx - fx) ** 2)
            newb1 = np.minimum(best1, d)
            best2 = np.minimum(best2, np.maximum(best1, d))
            best1 = newb1
    v = (best2 - best1) if kind == 'F2F1' else best1
    return nrm(v)


def hash01(i, salt=0):
    """Deterministic 0..1 hash of an integer array (wrap-safe: caller passes
    already-modulo'd indices, so identical indices hash identically)."""
    x = (i.astype(np.int64) + 1) * (374761393 + salt * 2654435761)
    x = (x ^ (x >> 13)) * 1274126177
    x = x ^ (x >> 16)
    return (x % 65536).astype(np.float32) / 65536.0


# ---------------------------------------------------------------- utilities
def nrm(a):
    lo, hi = float(a.min()), float(a.max())
    return (a - lo) / (hi - lo) if hi > lo else np.zeros_like(a)

def blur(a, s):
    """Wrapped gaussian blur. `s` may be a scalar or a per-axis (sy, sx) tuple
    for anisotropic streaking (rain runnels, brushed metal)."""
    if isinstance(s, (tuple, list)):
        return ndimage.gaussian_filter(a, s, mode='wrap')
    return ndimage.gaussian_filter(a, s, mode='wrap') if s > 0 else a

def sstep(a, e0, e1):
    t = np.clip((a - e0) / max(e1 - e0, 1e-6), 0, 1)
    return t * t * (3 - 2 * t)

def warp(a, wx, wy, amt):
    """Domain-warp a by vector field (wx,wy), wrapping at edges."""
    res = a.shape[0]
    c = np.arange(res, dtype=np.float32)
    gy, gx = np.meshgrid(c, c, indexing='ij')
    cy = (gy + (wy - 0.5) * amt) % res
    cx = (gx + (wx - 0.5) * amt) % res
    return ndimage.map_coordinates(a, [cy, cx], order=1, mode='wrap').astype(np.float32)

def erode(h, iters=28, rate=0.22, seed=0):
    """Cheap thermal/hydraulic-ish erosion: material creeps downslope, then
    settles into hollows. Gives sediment shelves and rounded upper edges."""
    h = h.copy()
    for _ in range(iters):
        gy, gx = np.gradient(h)
        slope = np.sqrt(gy * gy + gx * gx) + 1e-6
        flow = blur(slope, 1.1)
        h -= rate * 0.02 * flow                      # wear high-slope areas
        h += rate * 0.02 * blur(flow, 5) * 0.65      # deposit in basins
    return nrm(h)

def ao_from_height(h, radius=26, strength=1.0):
    """Multi-scale cavity/ambient occlusion from a heightfield."""
    ao = np.zeros_like(h)
    for r, w in ((radius * 0.25, 0.45), (radius, 0.35), (radius * 3, 0.20)):
        ao += w * np.clip(h - blur(h, r), -1, 1)
    ao = nrm(ao) * 2 - 1
    return np.clip(0.5 + ao * 0.62 * strength, 0, 1)

def curvature(h, r=2.0):
    return nrm(h - blur(h, r)) * 2 - 1

def normal_from_height(h, strength=2.6, res_scale=1.0):
    """Tangent-space normal map (OpenGL +Y) from a 0..1 heightfield.

    IMPORTANT: a Sobel returns the derivative PER TEXEL, which shrinks as the
    texture resolution grows - so a fixed `strength` produced an almost flat
    normal at 2K (mean nz ~0.997) even though the height had plenty of detail.
    We therefore convert to a per-tile derivative by scaling with the
    resolution, which makes `strength` resolution-independent and physically
    meaningful (it is roughly 'height amplitude in tile widths').
    """
    k = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], np.float32) / 8.0
    dx = ndimage.convolve(h, k, mode='wrap')
    dy = ndimage.convolve(h, k.T, mode='wrap')
    res = h.shape[0]
    # |dSobel| * res is ~constant across resolutions (measured 3.6 at 512,
    # 4.2 at 2048), so scaling by res/16 makes `strength` resolution-
    # independent and puts strength=1..4 in a useful slope range.
    s = strength * (res / 16.0) * res_scale
    nx = -dx * s
    ny = -dy * s
    nz = np.ones_like(h)
    l = np.sqrt(nx * nx + ny * ny + nz * nz)
    return np.stack([nx / l, ny / l, nz / l], -1)


def to_dx(n):
    """Convert OpenGL(+Y) normal array to DirectX(-Y), which UE expects."""
    o = n.copy(); o[..., 1] = -o[..., 1]; return o

def pack_normal(n):
    return np.clip((n * 0.5 + 0.5) * 255.0 + 0.5, 0, 255).astype(np.uint8)

def u8(a):
    return np.clip(a * 255.0 + 0.5, 0, 255).astype(np.uint8)

def u16(a):
    return np.clip(a * 65535.0 + 0.5, 0, 65535).astype(np.uint16)

def mix(a, b, t):
    t = t[..., None] if (a.ndim == 3 and t.ndim == 2) else t
    return a * (1 - t) + b * t

def srgb_noise(shape, rng, amt):
    return 1.0 + (rng.random(shape).astype(np.float32) - 0.5) * amt
