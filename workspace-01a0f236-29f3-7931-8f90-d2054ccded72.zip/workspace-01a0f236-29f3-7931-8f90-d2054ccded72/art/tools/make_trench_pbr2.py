# make_trench_pbr2.py — S15-TRENCH3 second texture batch (sandbox-side)
# corrugated / drum / ammo can / Persian rug -> PBR sets into the materials folder
import numpy as np
from PIL import Image, ImageFilter
import os

SRC = "art/trench_pbr2"
OUT = "SquadAI_TrenchMaterials/Textures"
SIZE = 2048


def load(name):
    return np.asarray(Image.open(f"{SRC}/{name}").convert("RGB"), dtype=np.float32) / 255.0


def make_seamless(img):
    h, w, _ = img.shape
    rolled = np.roll(np.roll(img, h // 2, axis=0), w // 2, axis=1)
    band = int(w * 0.10)
    yy, xx = np.mgrid[0:h, 0:w]
    dx = np.abs(xx - w // 2).astype(np.float32)
    dy = np.abs(yy - h // 2).astype(np.float32)
    m = np.maximum(np.clip(1 - dx / band, 0, 1), np.clip(1 - dy / band, 0, 1))
    m = (0.5 - 0.5 * np.cos(np.pi * m))[..., None]
    edge = int(w * 0.02)
    border = np.ones((h, w), np.float32)
    border[:edge, :] = 0; border[-edge:, :] = 0; border[:, :edge] = 0; border[:, -edge:] = 0
    return rolled * (1 - m * border[..., None]) + img * (m * border[..., None])


def resize(img, sw=SIZE, sh=SIZE):
    pil = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    return np.asarray(pil.resize((sw, sh), Image.LANCZOS), dtype=np.float32) / 255.0


def blur_gray(g, r):
    pil = Image.fromarray((np.clip(g, 0, 1) * 255).astype(np.uint8))
    return np.asarray(pil.filter(ImageFilter.GaussianBlur(r)), dtype=np.float32) / 255.0


def normal_from_height(h_map, strength):
    h_map = blur_gray(h_map, 1.2)
    gx = np.zeros_like(h_map); gy = np.zeros_like(h_map)
    gx[:, 1:-1] = (h_map[:, 2:] - h_map[:, :-2]) * 0.5
    gy[1:-1, :] = (h_map[2:, :] - h_map[:-2, :]) * 0.5
    gx[:, 0] = (h_map[:, 1] - h_map[:, -1]) * 0.5
    gx[:, -1] = (h_map[:, 0] - h_map[:, -2]) * 0.5
    gy[0, :] = (h_map[1, :] - h_map[-1, :]) * 0.5
    gy[-1, :] = (h_map[0, :] - h_map[-2, :]) * 0.5
    nx = -gx * strength; ny = gy * strength; nz = np.ones_like(h_map)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    return np.stack([nx / ln, ny / ln, nz / ln], axis=-1) * 0.5 + 0.5


def lum(img):
    return img[..., 0] * 0.299 + img[..., 1] * 0.587 + img[..., 2] * 0.114


def save(img, name):
    Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).save(f"{OUT}/{name}.png")
    print("saved", name)


def build(src, tag, n_strength, r_base, r_var, invert=True, seamless=True):
    img = load(src)
    if seamless:
        img = make_seamless(img)
    bc = resize(img)
    save(bc, f"T_Trench{tag}_BC")
    save(normal_from_height(blur_gray(lum(bc), 0.8), n_strength), f"T_Trench{tag}_N")
    v = lum(bc) - lum(bc).mean()
    if invert:
        v = -v
    save(np.stack([np.clip(r_base + v * r_var, 0.05, 1.0)] * 3, -1), f"T_Trench{tag}_R")


# Corrugated: deep ridges -> strong normal; rust streaks rough, zinc smoother
build("src_corrugated.png", "Corrugated", 5.0, 0.55, 0.6, invert=True)
# Drum: olive paint semi-smooth, rust/chips rough
build("src_drum.png", "Drum", 2.6, 0.50, 0.7, invert=True)
# Ammo can: pressed steel, worn paint
build("src_ammocan.png", "AmmoCan", 2.0, 0.55, 0.5, invert=True)

# Rug: NOT tiled — one full rug per plane. Crop the dirt margin, keep 2:1.
rug = load("src_rug.png")
h, w, _ = rug.shape
cy, cx = int(h * 0.045), int(w * 0.035)
rug = rug[cy:h - cy, cx:w - cx]
rug_bc = resize(rug, 2048, 1024)
save(rug_bc, "T_TrenchRug_BC")
save(normal_from_height(blur_gray(lum(rug_bc), 0.6), 1.1), "T_TrenchRug_N")
print("done")
