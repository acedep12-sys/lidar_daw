# make_trench_pbr.py — S15-TRENCH PBR pipeline (runs in sandbox, NOT on user machine)
# src photoreal albedos -> seamless 2K BaseColor + Normal + Roughness (+ scorch decal w/ alpha)
import numpy as np
from PIL import Image, ImageFilter
import os

SRC = "art/trench_pbr"
OUT = "SquadAI_TrenchMaterials/Textures"
os.makedirs(OUT, exist_ok=True)
SIZE = 2048


def load(name):
    return np.asarray(Image.open(f"{SRC}/{name}").convert("RGB"), dtype=np.float32) / 255.0


def make_seamless(img):
    """Offset by half so borders tile by construction, then hide the central
    seam cross by feather-blending the original image over it."""
    h, w, _ = img.shape
    rolled = np.roll(np.roll(img, h // 2, axis=0), w // 2, axis=1)
    band = int(w * 0.10)
    yy, xx = np.mgrid[0:h, 0:w]
    dx = np.abs(xx - w // 2).astype(np.float32)
    dy = np.abs(yy - h // 2).astype(np.float32)
    mx = np.clip(1.0 - dx / band, 0.0, 1.0)
    my = np.clip(1.0 - dy / band, 0.0, 1.0)
    m = np.maximum(mx, my)
    m = (0.5 - 0.5 * np.cos(np.pi * m))[..., None]  # cosine feather
    # keep borders pure 'rolled' so tiling stays exact
    edge = int(w * 0.02)
    border = np.ones((h, w), np.float32)
    border[:edge, :] = 0; border[-edge:, :] = 0; border[:, :edge] = 0; border[:, -edge:] = 0
    m = m * border[..., None]
    return rolled * (1 - m) + img * m


def resize(img, size=SIZE):
    pil = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    return np.asarray(pil.resize((size, size), Image.LANCZOS), dtype=np.float32) / 255.0


def blur_gray(g, r):
    pil = Image.fromarray((np.clip(g, 0, 1) * 255).astype(np.uint8))
    return np.asarray(pil.filter(ImageFilter.GaussianBlur(r)), dtype=np.float32) / 255.0


def normal_from_height(h_map, strength):
    h_map = blur_gray(h_map, 1.2)
    gx = np.zeros_like(h_map); gy = np.zeros_like(h_map)
    gx[:, 1:-1] = (h_map[:, 2:] - h_map[:, :-2]) * 0.5
    gy[1:-1, :] = (h_map[2:, :] - h_map[:-2, :]) * 0.5
    # wrap edges so the normal map tiles too
    gx[:, 0] = (h_map[:, 1] - h_map[:, -1]) * 0.5
    gx[:, -1] = (h_map[:, 0] - h_map[:, -2]) * 0.5
    gy[0, :] = (h_map[1, :] - h_map[-1, :]) * 0.5
    gy[-1, :] = (h_map[0, :] - h_map[-2, :]) * 0.5
    nx = -gx * strength; ny = gy * strength; nz = np.ones_like(h_map)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    n = np.stack([nx / ln, ny / ln, nz / ln], axis=-1)
    return n * 0.5 + 0.5


def save(img, name, mode="RGB"):
    arr = (np.clip(img, 0, 1) * 255).astype(np.uint8)
    Image.fromarray(arr, mode).save(f"{OUT}/{name}.png")
    print("saved", name, arr.shape)


def lum(img):
    return img[..., 0] * 0.299 + img[..., 1] * 0.587 + img[..., 2] * 0.114


def build(src, tag, normal_strength, rough_base, rough_var, rough_invert=False):
    bc = resize(make_seamless(load(src)))
    save(bc, f"T_Trench{tag}_BC")
    l = lum(bc)
    height = blur_gray(l, 0.8)
    save(normal_from_height(height, normal_strength), f"T_Trench{tag}_N")
    v = l - l.mean()
    if rough_invert:
        v = -v
    rough = np.clip(rough_base + v * rough_var, 0.05, 1.0)
    save(np.stack([rough] * 3, axis=-1), f"T_Trench{tag}_R")
    return bc


build("src_wood.png",   "Wood",   3.0, 0.78, 0.9, rough_invert=True)   # cracks rougher
canvas = build("src_canvas.png", "Canvas", 1.8, 0.88, 0.4, rough_invert=True)
earth = build("src_earth.png",  "Earth",  3.5, 0.86, 0.5, rough_invert=True)

# Metal: rust (red-dominant) is rough, remaining paint smoother
bc = resize(make_seamless(load("src_metal.png")))
save(bc, "T_TrenchMetal_BC")
save(normal_from_height(blur_gray(lum(bc), 0.8), 2.2), "T_TrenchMetal_N")
rust = np.clip((bc[..., 0] - bc[..., 1]) * 4.0 + 0.2, 0.0, 1.0)
rough = np.clip(0.45 + rust * 0.45 + (lum(bc) - lum(bc).mean()) * 0.2, 0.05, 1.0)
save(np.stack([rough] * 3, axis=-1), "T_TrenchMetal_R")

# Scorch decal: charred earth + soft irregular radial alpha splat
char = earth * np.array([0.13, 0.115, 0.10])  # burnt, slightly warm-black
char = np.clip(char + (lum(earth)[..., None] - 0.5) * 0.05, 0, 1)  # keep texture detail
save(char, "T_TrenchScorch_BC")
yy, xx = np.mgrid[0:SIZE, 0:SIZE].astype(np.float32)
cx = cy = SIZE / 2
r = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / (SIZE / 2)
rng = np.random.default_rng(1367)
noise = rng.random((64, 64)).astype(np.float32)
noise = np.asarray(Image.fromarray((noise * 255).astype(np.uint8)).resize((SIZE, SIZE), Image.BICUBIC), np.float32) / 255.0
edge = r + (noise - 0.5) * 0.55           # ragged edge
alpha = np.clip(1.0 - (edge - 0.25) / 0.55, 0.0, 1.0) ** 1.5
alpha *= np.clip(0.55 + noise * 0.7, 0, 1)  # patchy interior
rgba = np.dstack([char, alpha])
save(rgba, "T_TrenchScorch_BC", mode="RGBA")
print("done")
