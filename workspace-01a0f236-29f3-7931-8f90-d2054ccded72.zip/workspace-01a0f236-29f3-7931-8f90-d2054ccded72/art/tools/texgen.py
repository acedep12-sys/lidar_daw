#!/usr/bin/env python3
"""
texgen.py — SquadAI PBR texture generator CLI.

Renders tileable, high-detail PBR material sets for the Dehloran / Ilam
(Dehlavieh hills) setting. Pure numpy + scipy + Pillow; no external assets.

USAGE
    python3 texgen.py <material> [--res N] [--seed N] [--out DIR] [--preview]
    python3 texgen.py --list

    <material>   name of a generator module, e.g. mudbrick, ground, rubble
    --res N      output resolution. 2048 (default) | 1024 | 512 | 256
                 Use --res 1024 for a lighter/faster set, --res 512 to preview.
    --seed N     change the seed for a different variation of the same surface.
    --out DIR    output directory (default: /home/user/art/textures/<material>)
    --preview    also write a small lit sphere/plane preview PNG for eyeballing.
    --packed     pack ORM + Height into a single RGBA file (halves disk use).

OUTPUT (UE-ready naming)
    T_<Name>_BC.png    Base Colour        sRGB,   8-bit RGB
    T_<Name>_N.png     Normal (DirectX)   Linear, 8-bit RGB   <- UE default is DX
    T_<Name>_ORM.png   Occlusion/Rough/Metal  Linear, 8-bit RGB
    T_<Name>_H.png     Height             Linear, 16-bit grey
    T_<Name>_DN.png    Detail Normal (DX) Linear, 8-bit RGB
    (--packed replaces ORM+H with T_<Name>_ORMH.png, RGBA)

MEMORY
    2K generation peaks near 1.4 GB. The writer streams maps to disk one at a
    time and frees each immediately, so the peak is the generator itself.
    If a 2K run is killed, use --res 1024.
"""
import argparse
import gc
import importlib
import importlib.util
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
from PIL import Image

# Registry: material name -> (module, UE asset basename)
MATERIALS = {
    'mudbrick': ('mat_mudbrick', 'Village_MudbrickWall'),
    'ground':   ('mat_ground',   'Village_GroundDirt'),
    'rubble':   ('mat_rubble',   'Village_Rubble'),
    'wood':     ('mat_wood',     'Village_WoodBeam'),
}


# ----------------------------------------------------------------- writers
def _save(path, arr, bits=8):
    """Write a map and free it. arr is float 0..1, shape HxW or HxWxC."""
    if bits == 16:
        img = Image.fromarray(np.clip(arr, 0, 1).astype(np.float32).__mul__(65535.0)
                              .round().astype(np.uint16))
    else:
        img = Image.fromarray((np.clip(arr, 0, 1) * 255.0 + 0.5).astype(np.uint8))
    img.save(path, optimize=True)
    size = os.path.getsize(path) / 1e6
    del img
    gc.collect()
    return size


def write_set(maps, outdir, basename, packed=False):
    """Stream every map to disk, freeing as we go. Returns (files, total MB)."""
    os.makedirs(outdir, exist_ok=True)
    written = []
    total = 0.0

    def emit(key, suffix, transform=None, bits=8):
        nonlocal total
        if key not in maps or maps[key] is None:
            return
        arr = maps.pop(key)                      # pop: drop the generator's ref
        if transform is not None:
            arr = transform(arr)
        path = os.path.join(outdir, 'T_%s_%s.png' % (basename, suffix))
        mb = _save(path, arr, bits=bits)
        del arr
        gc.collect()
        written.append((os.path.basename(path), mb))
        total += mb

    emit('albedo', 'BC')
    emit('normal', 'N', transform=lambda n: n * 0.5 + 0.5)

    if packed:
        orm = maps.pop('orm', None)
        h = maps.pop('height', None)
        if orm is not None and h is not None:
            rgba = np.concatenate([orm, h[..., None]], -1)
            del orm, h
            gc.collect()
            path = os.path.join(outdir, 'T_%s_ORMH.png' % basename)
            mb = _save(path, rgba, bits=8)
            del rgba
            gc.collect()
            written.append((os.path.basename(path), mb))
            total += mb
    else:
        emit('orm', 'ORM')
        emit('height', 'H', bits=16)

    emit('detail_normal', 'DN', transform=lambda n: n * 0.5 + 0.5)
    return written, total


# ----------------------------------------------------------------- preview
DETAIL_PREVIEW_TILES = 6   # must match the UE material's DetailTiling


def lit_preview(maps_ref, path, size=700):
    """Cheap deferred-style relight so bump/roughness can be judged by eye.
    Takes a dict that still holds albedo/normal/orm/height (call before write)."""
    alb = maps_ref['albedo']
    n = maps_ref['normal']
    orm = maps_ref['orm']
    res = alb.shape[0]
    step = max(1, res // size)
    a = alb[::step, ::step]
    nn = n[::step, ::step].copy()
    nn[..., 1] = -nn[..., 1]                      # DX -> GL for shading math
    # Composite the detail normal the way the UE material will (whiteout blend,
    # detail tiled several times) so the preview reflects real in-engine relief.
    dn = maps_ref.get('detail_normal')
    if dn is not None:
        # BUGFIX: np.tile(...)[:H,:W] just crops back to the first tile, so the
        # detail normal was composited at 1:1 instead of tiled. That made the
        # preview show DN blobs at full size (they read as popcorn) when in
        # engine the DN tiles ~8x and is a fine tooth. Downsample THEN tile.
        k = DETAIL_PREVIEW_TILES
        d = dn[::step, ::step]
        d = d[::k, ::k].copy()                                  # shrink one tile
        reps = int(np.ceil(nn.shape[0] / max(1, d.shape[0])))
        d = np.tile(d, (reps, reps, 1))[:nn.shape[0], :nn.shape[1]]
        d[..., 1] = -d[..., 1]
        nn = np.stack([nn[..., 0] + d[..., 0], nn[..., 1] + d[..., 1],
                       nn[..., 2] * d[..., 2]], -1)
        nn /= (np.linalg.norm(nn, axis=-1, keepdims=True) + 1e-6)
    ao = orm[::step, ::step, 0]
    rough = orm[::step, ::step, 1]

    L = np.array([-0.45, 0.42, 0.79], np.float32)   # warm low sun
    L /= np.linalg.norm(L)
    V = np.array([0.0, 0.0, 1.0], np.float32)
    H = L + V
    H /= np.linalg.norm(H)

    ndl = np.clip((nn * L).sum(-1), 0, 1)
    ndh = np.clip((nn * H).sum(-1), 0, 1)
    sun = np.array([1.04, 0.94, 0.78], np.float32)
    sky = np.array([0.34, 0.42, 0.56], np.float32)

    gloss = (1.0 - rough) ** 4
    spec = (ndh ** (4 + gloss * 200)) * gloss * 0.5
    up = np.clip(nn[..., 2], 0, 1)

    col = (a * (ndl[..., None] * sun * 1.18
                + up[..., None] * sky * 0.30 * ao[..., None]
                + 0.05 * ao[..., None])
           + spec[..., None] * sun * 0.9)
    col = np.clip(col, 0, 1) ** (1 / 2.2)
    Image.fromarray((col * 255).astype(np.uint8)).save(path)
    return path


# ----------------------------------------------------------------- driver
def main():
    ap = argparse.ArgumentParser(
        description='SquadAI PBR texture generator (Dehlavieh hills palette).',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='Example:  python3 texgen.py mudbrick --res 1024 --preview')
    ap.add_argument('material', nargs='?', help='material name (see --list)')
    ap.add_argument('--res', type=int, default=2048,
                    help='resolution: 2048 (default), 1024, 512, 256')
    ap.add_argument('--seed', type=int, default=None, help='variation seed')
    ap.add_argument('--out', default=None, help='output directory')
    ap.add_argument('--preview', action='store_true', help='also write a lit preview')
    ap.add_argument('--packed', action='store_true', help='pack ORM+Height as RGBA')
    ap.add_argument('--list', action='store_true', help='list materials and exit')
    args = ap.parse_args()

    if args.list or not args.material:
        print('Available materials:')
        for k, (mod, base) in MATERIALS.items():
            state = 'ready' if importlib.util.find_spec(mod) else 'NOT BUILT YET'
            print('  %-10s -> T_%-22s [%s]' % (k, base, state))
        print('\nResolutions: --res 2048 | 1024 | 512 | 256')
        return 0

    if args.material not in MATERIALS:
        print('Unknown material %r. Use --list.' % args.material, file=sys.stderr)
        return 2
    if args.res not in (256, 512, 1024, 2048, 4096):
        print('--res must be 256, 512, 1024, 2048 or 4096', file=sys.stderr)
        return 2

    modname, basename = MATERIALS[args.material]
    try:
        mod = importlib.import_module(modname)
    except ImportError as e:
        print('Generator %s is not available: %s' % (modname, e), file=sys.stderr)
        return 3

    outdir = args.out or os.path.join('/home/user/art/textures', args.material)
    kw = {'res': args.res}
    if args.seed is not None:
        kw['seed'] = args.seed

    print('Generating %s at %dx%d ...' % (args.material, args.res, args.res))
    t0 = time.time()
    maps = mod.build(**kw)
    gen_s = time.time() - t0
    print('  generated in %.1fs' % gen_s)

    if args.preview:
        os.makedirs(outdir, exist_ok=True)
        p = lit_preview(maps, os.path.join(outdir, '_preview_lit.png'))
        print('  preview: %s' % p)

    files, total = write_set(maps, outdir, basename, packed=args.packed)
    for name, mb in files:
        print('  %-34s %6.2f MB' % (name, mb))
    print('TOTAL %.1f MB in %s  (%.1fs)' % (total, outdir, time.time() - t0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
