"""T_Village_WoodBeam — weathered timber: roof beams, lintels, door frames, planks.

Khuzestan / Dehlavieh reference (دفاع مقدس). Village roofs are carried on rough
palm-trunk and poplar poles with sawn planks over them, all sun-bleached to a
silvery grey on the exposed faces while the sheltered grain stays warm brown.

Art notes
---------
* Grain direction runs along U. Every anisotropic term uses the SAME axis, so
  the boards read as one consistent material rather than crosshatch noise.
* Boards are separated by dark gaps rather than by colour alone: the gap shadow
  is what makes planking legible at a distance.
* Weathering is patchy and correlated with height - raised, exposed fibres go
  silver first while the recesses stay dark. Uniform grey looks like paint.

Lessons already applied (MATERIAL_RECORDS.md):
  - srgb_noise is a MULTIPLIER (1.0 +/- amt), never added.
  - Worley distances that get thresholded stay in RAW cell units.
  - Colour/variant selection uses a hash DECORRELATED from the presence hash.
  - Normal strength calibrated at 2048 and quoted in PACKED space.
  - Detail-normal strength scales INVERSELY with base relief.
"""
import gc, sys, numpy as np
sys.path.insert(0, '/home/user/art/tools')
import texlib as T


def build(res=2048, seed=4501):
    rng = np.random.default_rng(seed)
    S = res / 2048.0

    c = np.linspace(0, 1, res, endpoint=False, dtype=np.float32)
    gy, gx = np.meshgrid(c, c, indexing='ij')

    # ---------------------------------------------------------------- boards
    # Boards run along U (horizontal). Widths vary so the tile does not read as
    # a ruler-even grid.
    boards = 5
    edge_wob = (T.fbm(res, 6, 4, seed=seed + 1) - 0.5) * (0.16 / boards)
    by = gy + edge_wob
    bf = by * boards
    b_i = np.floor(bf).astype(np.int32) % boards      # WRAP: modulo board count
    b_t = bf - np.floor(bf)

    # Per-board identity, wrap-safe (identical indices hash identically).
    b_id = T.hash01(b_i, salt=3)

    # Gap between boards: a narrow, dark, recessed seam.
    gap = 1.0 - (T.sstep(b_t, 0.0, 0.045) * T.sstep(1.0 - b_t, 0.0, 0.045))

    # Each board sits at a slightly different height and tilt (warped timber).
    board_h = (b_id - 0.5) * 0.16
    board_h += np.sin(b_t * np.pi) * 0.05          # slight crown across the board

    h = 0.55 + board_h - gap * 0.42

    # ---------------------------------------------------------------- grain
    # Strongly anisotropic along U. Two scales: broad figure + fine fibre.
    grain_a = T.blur(T.fbm(res, 26, 5, seed=seed + 10) - 0.5, (0.6 * S, 26.0 * S))
    grain_b = T.blur(T.fbm(res, 70, 4, seed=seed + 11) - 0.5, (0.4 * S, 14.0 * S))
    grain_c = T.blur(T.fbm(res, 150, 3, seed=seed + 12) - 0.5, (0.3 * S, 7.0 * S))
    grain = T.nrm(grain_a * 0.5 + grain_b * 0.32 + grain_c * 0.18)

    # Growth rings.
    # NOTE: deriving these from `grain % 1.0` produces CONTOURS of a 2D noise
    # field - closed concentric loops, i.e. a maze/coral pattern, not wood.
    # Rings must be bands running ALONG the board, so the ramp is driven by the
    # across-grain coordinate (V) and only displaced by noise that has been
    # blurred along U. That keeps every line long and roughly parallel.
    ring_warp = T.blur(T.fbm(res, 22, 5, seed=seed + 13) - 0.5, (1.0 * S, 30.0 * S))
    ring_warp += T.blur(T.fbm(res, 60, 4, seed=seed + 14) - 0.5, (0.6 * S, 18.0 * S)) * 0.5
    # CRITICAL: the displacement must be a FRACTION of one ring period. An
    # earlier version used 6.0 - six whole periods - which let the bands slide
    # past each other and re-form along the noise contours, reproducing exactly
    # the maze/coral pattern this rewrite was meant to remove.
    ring_field = gy * 34.0 + (T.nrm(ring_warp) - 0.5) * 0.85
    rings = np.abs((ring_field % 1.0) - 0.5) * 2.0
    rings = T.sstep(rings, 0.20, 0.90)

    h += (grain - 0.5) * 0.10
    h -= (1.0 - rings) * 0.045          # soft earlywood sits lower than latewood

    # ---------------------------------------------------------------- splits
    # Checks open ALONG the grain: long, thin, and only on some boards.
    split_n = T.blur(T.fbm(res, 40, 4, seed=seed + 20), (0.5 * S, 34.0 * S))
    split = T.sstep(T.nrm(split_n), 0.80, 0.975)
    split *= T.sstep(T.hash01(b_i, salt=9), 0.35, 0.75)   # not every board
    split *= 1.0 - gap
    h -= split * 0.17

    # ---------------------------------------------------------------- knots
    # A few knots, each with the grain pinched around it.
    kd = T.worley(res, 7, seed=seed + 30, kind='F1')
    kn_id = T.fbm(res, 7, 2, seed=seed + 31)
    knot_core = (1.0 - T.sstep(kd, 0.06, 0.16)) * T.sstep(kn_id, 0.62, 0.80)
    knot_ring = (1.0 - T.sstep(np.abs(kd - 0.20), 0.0, 0.09)) * T.sstep(kn_id, 0.62, 0.80)
    h -= knot_core * 0.10
    h += knot_ring * 0.03

    # ---------------------------------------------------------------- saw / wear
    # Faint tooling across the grain, plus rounded-off board edges.
    saw = T.blur(T.fbm(res, 110, 3, seed=seed + 40) - 0.5, (5.0 * S, 0.4 * S))
    h += saw * 0.018 * (1.0 - gap)

    h += (T.fbm(res, 120, 4, seed=seed + 41) - 0.5) * 0.020
    h = T.nrm(h)
    hb = T.blur(h, 1.1 * S)

    # ---------------------------------------------------------------- albedo
    wood_deep  = np.array([0.098, 0.062, 0.036], np.float32)   # shadowed grain
    wood_mid   = np.array([0.238, 0.155, 0.088], np.float32)
    wood_warm  = np.array([0.395, 0.278, 0.165], np.float32)
    wood_pale  = np.array([0.512, 0.404, 0.268], np.float32)   # fresh sawn
    silver     = np.array([0.352, 0.325, 0.288], np.float32)   # sun-bleached
    gap_dark   = np.array([0.028, 0.020, 0.014], np.float32)
    knot_col   = np.array([0.072, 0.045, 0.026], np.float32)

    # Per-board base tone, then grain and rings modulate within the board.
    b_tone = (b_id * 0.75 + T.fbm(res, 12, 4, seed=seed + 50) * 0.25)[..., None]
    alb = T.mix(wood_mid, wood_warm, b_tone)

    alb = T.mix(alb, wood_deep, ((1.0 - rings) * 0.55)[..., None])
    alb = T.mix(alb, wood_pale, (T.sstep(grain, 0.62, 1.0) * 0.32)[..., None])

    # Sun-bleaching: patchy, and biased to raised/exposed fibre.
    weather = T.warp(T.fbm(res, 5, 5, seed=seed + 51),
                     T.fbm(res, 13, 4, seed=seed + 52),
                     T.fbm(res, 13, 4, seed=seed + 53), 30 * S)
    weather = T.sstep(T.nrm(weather), 0.30, 0.85)
    weather = weather * (0.45 + 0.55 * T.sstep(hb, 0.45, 0.95))
    alb = T.mix(alb, silver, (weather * 0.62)[..., None])

    # Splits and knots are dark holes.
    alb = T.mix(alb, wood_deep, (split * 0.70)[..., None])
    alb = T.mix(alb, knot_col, (knot_core * 0.88)[..., None])
    alb = T.mix(alb, wood_deep, (knot_ring * 0.35)[..., None])

    # Board seams last so nothing bleeds across them.
    alb = T.mix(alb, gap_dark, (gap * 0.92)[..., None])

    alb = np.clip(alb * T.srgb_noise((res, res, 1), rng, 0.030), 0, 1)

    # ---------------------------------------------------------------- ORM
    ao = T.ao_from_height(h, radius=22, strength=1.05)
    ao *= 1.0 - gap * 0.45            # seams read as deep shadow
    ao *= 1.0 - split * 0.30
    ao = np.clip(ao, 0.0, 1.0)

    # Weathered timber is very matt; sheltered grain keeps a little sheen.
    rough = np.full((res, res), 0.78, np.float32)
    rough += weather * 0.16           # silvered fibre is dead matt
    rough += split * 0.06
    rough += knot_core * -0.10        # knots are resinous and slightly glossy
    rough -= T.sstep(grain, 0.70, 1.0) * 0.05
    rough += (T.fbm(res, 18, 5, seed=seed + 60) - 0.5) * 0.08
    rough += (T.fbm(res, 62, 4, seed=seed + 61) - 0.5) * 0.05
    rough = np.clip(rough, 0.40, 1.0)

    metal = np.zeros((res, res), np.float32)
    orm = np.stack([ao, rough, metal], -1)
    del ao, rough, metal, weather, rings, split, knot_core, knot_ring, saw, gap
    gc.collect()

    # ---------------------------------------------------------------- normals
    # Calibrated at 2048, PACKED space, against the rest of the village set:
    #   rubble 0.797 | kahgel wall 0.826 | wood 0.845 | ground 0.875
    # Timber has real relief at the board seams and splits, but the faces
    # themselves are close to planar.
    nrmmap = T.to_dx(T.normal_from_height(h, strength=2.2, res_scale=S))

    # Detail normal (~8x): fine fibre along the grain. Moderate strength - the
    # base already carries seams and splits, so a strong DN just adds fuzz.
    # Fibre only, and strictly along U. An isotropic term here reads as fuzz
    # and, combined with the ring bands, was part of the maze look.
    dh = (T.blur(T.fbm(res, 150, 4, seed=seed + 70) - 0.5, (0.35 * S, 16.0 * S)) * 0.55
          + T.blur(T.fbm(res, 230, 3, seed=seed + 71) - 0.5, (0.30 * S, 9.0 * S)) * 0.33
          + T.blur(T.fbm(res, 90, 3, seed=seed + 72) - 0.5, (0.5 * S, 22.0 * S)) * 0.12)
    dn = T.to_dx(T.normal_from_height(T.nrm(dh), strength=0.50, res_scale=S))
    del dh, hb, grain
    gc.collect()

    return dict(albedo=alb, normal=nrmmap, detail_normal=dn, height=h, orm=orm)
