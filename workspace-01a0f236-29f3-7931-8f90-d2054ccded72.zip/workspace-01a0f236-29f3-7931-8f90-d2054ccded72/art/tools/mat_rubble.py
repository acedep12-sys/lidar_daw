"""T_Village_Rubble — collapsed adobe/kahgel masonry debris.

Khuzestan / Dehlavieh reference (دفاع مقدس), matched to the kahgel wall palette
so a broken building reads as the SAME material that fell down: warm red-ochre
mud-and-straw lumps, adobe brick fragments, pale pulverised gypsum, and a bed of
fine ochre dust that the chunks are half-buried in.

Key art notes
-------------
* Real rubble is mostly FINES. Big recognisable chunks are the minority - if the
  whole tile is chunks it reads as a gravel texture, not a collapsed wall. Here
  the dust bed dominates and chunks sit partly sunk into it.
* Adobe breaks along bedding planes, so fragments are ANGULAR and slab-like with
  flat tops, not rounded pebbles. Euclidean Worley gives round blobs, so the
  chunk cells use a per-cell rotated Chebyshev metric to get flat faces and
  straight edges.
* Three chunk scales (slabs / bricks / spall) keep it from looking like one
  repeated size, which is the usual giveaway on procedural debris.
* Everything here is wrap-safe (fbm lattice, worley cell wrap, blur/convolve
  mode='wrap'), so the result tiles seamlessly.
"""
import gc, sys, numpy as np
sys.path.insert(0, '/home/user/art/tools')
import texlib as T


def _cells(res, cells, seed, angular=0.75):
    """Wrapped cellular field with per-cell identity.

    Returns (d1, edge, chash) where
      d1    0..1  distance to the cell's feature point (0 at the centre)
      edge  0..1  F2-F1, ~0 exactly on a cell boundary
      chash 0..1  a stable per-cell random value (same for every pixel in a cell)

    `angular` blends the distance metric from Euclidean (0, round pebbles)
    toward a per-cell rotated Chebyshev metric (1, flat-faced angular slabs).
    """
    rng = np.random.default_rng(seed)
    jit = rng.random((cells, cells, 2)).astype(np.float32)
    rot = rng.random((cells, cells)).astype(np.float32) * np.pi  # per-chunk rotation
    idh = rng.random((cells, cells)).astype(np.float32)          # per-chunk identity

    c = np.linspace(0, 1, res, endpoint=False, dtype=np.float32) * cells
    gy, gx = np.meshgrid(c, c, indexing='ij')
    cy = np.floor(gy).astype(np.int32)
    cx = np.floor(gx).astype(np.int32)

    best1 = np.full((res, res), 1e9, np.float32)
    best2 = np.full((res, res), 1e9, np.float32)
    owner = np.zeros((res, res), np.float32)
    # local coords inside the winning chunk's own rotated frame, used to tilt it
    loc_y = np.zeros((res, res), np.float32)
    loc_x = np.zeros((res, res), np.float32)

    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            ny = (cy + dy) % cells
            nx = (cx + dx) % cells
            fy = (cy + dy) + jit[ny, nx, 0]
            fx = (cx + dx) + jit[ny, nx, 1]
            vy = gy - fy
            vx = gx - fx

            # rotate into the chunk's own frame so its flat faces are not all
            # axis-aligned (axis-aligned chunks read as a tiled grid).
            a = rot[ny, nx]
            ca = np.cos(a); sa = np.sin(a)
            ry = vy * ca - vx * sa
            rx = vy * sa + vx * ca

            d_euc = np.sqrt(vy * vy + vx * vx)
            d_box = np.maximum(np.abs(ry), np.abs(rx))
            d = d_euc * (1.0 - angular) + d_box * angular

            closer = d < best1
            owner = np.where(closer, idh[ny, nx], owner)
            loc_y = np.where(closer, ry, loc_y)
            loc_x = np.where(closer, rx, loc_x)
            newb1 = np.minimum(best1, d)
            best2 = np.minimum(best2, np.maximum(best1, d))
            best1 = newb1
            del ny, nx, fy, fx, vy, vx, a, ca, sa, ry, rx, d_euc, d_box, d, closer

    # NOTE: best1 is returned in RAW cell-space units (0 at the feature point,
    # ~0.5 at the cell boundary). Normalising it - as an earlier version did -
    # rescales every chunk against the global min/max, so the flat-top falloff
    # band stopped lining up with the cell edge and every fragment domed over
    # into a rounded lump. That is what made the first render read as cracked
    # mud instead of broken masonry.
    return best1, T.nrm(best2 - best1), owner, loc_y, loc_x


def _chunk_layer(res, cells, seed, coverage, thickness, angular=0.75):
    """One scale of debris. Returns (height_add, mask, chash).

    Only cells whose identity falls under `coverage` actually contain a chunk;
    the rest is left as dust bed. Chunks get a flat top that falls away at the
    rim, so they look like broken slabs sitting in the fines rather than bumps.
    """
    d1, edge, chash, ly, lx = _cells(res, cells, seed, angular)

    present = (chash < coverage).astype(np.float32)
    # soften presence a touch so chunk borders are not a hard binary cut
    present = T.blur(present, 0.6)

    # Flat-topped profile in raw cell units: solid across the body of the chunk,
    # then a short, steep rim. The narrow band (0.30 -> 0.44) is what gives adobe
    # its broken-slab silhouette instead of a pebble.
    top = 1.0 - T.sstep(d1, 0.30, 0.44)
    # per-chunk thickness variation
    tvar = 0.55 + 1.0 * chash
    body = top * present * tvar

    # Per-fragment TILT. Without this every chunk's top face is parallel to the
    # ground and the tile reads as stamped tiles lying on sand. Each chunk gets
    # its own slope direction/steepness keyed off its identity hash, so pieces
    # lean on each other the way collapsed masonry actually settles.
    ta = chash * 6.2831853
    tilt_amt = (0.25 + 0.75 * T.hash01((chash * 997).astype(np.int32), salt=5))
    tilt = (ly * np.cos(ta) + lx * np.sin(ta)) * tilt_amt * 1.35
    body = np.clip(body * (1.0 + tilt), 0.0, None)

    # chip the edges: fine noise eats into the rim where it is thin
    # two frequencies, otherwise every fragment gets an identical notch
    chip = (T.fbm(res, max(8, cells * 2), 4, seed=seed + 991) * 0.6
            + T.fbm(res, max(14, cells * 5), 3, seed=seed + 993) * 0.4)
    body *= 1.0 - T.sstep(chip * (1.0 - top), 0.12, 0.42) * 0.85

    # `chash` decides PRESENCE (chunk exists where chash < coverage), so it only
    # ever spans 0..coverage on a chunk that actually exists. Using it to drive
    # colour meant every fragment landed at the dark end of its range (the whole
    # tile came out one flat ochre), and variant tests like `id > 0.8` could
    # never fire at all. Derive an independent, full-range 0..1 identity instead.
    vhash = T.hash01((chash * 65535.0).astype(np.int32), salt=11)
    return body * thickness, T.sstep(body, 0.06, 0.30), vhash


def build(res=2048, seed=2301):
    rng = np.random.default_rng(seed)
    S = res / 2048.0

    # ---------------------------------------------------------------- dust bed
    # Fines the chunks are bedded into: broad drifts + a fine granular tooth.
    bed = (T.fbm(res, 5, 7, seed=seed + 1) * 0.62
           + T.fbm(res, 17, 6, seed=seed + 2) * 0.26
           + T.fbm(res, 60, 4, seed=seed + 3) * 0.12)
    bed = T.nrm(bed)
    # let the dust settle: hollows fill, drift tops round off
    bed = T.erode(bed, iters=16, rate=0.18, seed=seed + 4)
    h = bed * 0.46
    del bed

    # ---------------------------------------------------------------- chunks
    # slabs: rare, large, the silhouette-defining pieces
    slab_h, slab_m, slab_id = _chunk_layer(res, 7,  seed + 10, coverage=0.30,
                                           thickness=0.72, angular=0.86)
    # bricks: the workhorse scale, recognisable adobe fragments
    brick_h, brick_m, brick_id = _chunk_layer(res, 15, seed + 20, coverage=0.38,
                                              thickness=0.42, angular=0.82)
    # spall: small broken corners and lumps of kahgel
    spall_h, spall_m, spall_id = _chunk_layer(res, 34, seed + 30, coverage=0.36,
                                              thickness=0.19, angular=0.70)

    # Stack so bigger pieces sit on top of / occlude smaller ones.
    # Each chunk sits ON the dust bed at its own local bed height, so fragments
    # look half-buried in fines rather than fused into one crust.
    h = np.maximum(h, h + slab_h)
    h = np.maximum(h, h + brick_h)
    h = np.maximum(h, h + spall_h)

    # gravel and grit scattered through the fines
    grit = T.worley(res, 150, seed=seed + 40, kind='F1')
    h += (1.0 - grit) * 0.035 * (1.0 - slab_m * 0.7)
    del grit

    # a few rebar/timber-scrape gouges through the dust
    gouge = T.fbm(res, 3, 4, seed=seed + 41)
    gouge = T.warp(gouge, T.fbm(res, 9, 4, seed=seed + 42),
                   T.fbm(res, 9, 4, seed=seed + 43), 26 * S)
    gouge_m = T.sstep(gouge, 0.78, 0.93) * (1.0 - slab_m) * (1.0 - brick_m)
    h -= gouge_m * 0.05
    del gouge

    h = T.nrm(h)
    hb = T.blur(h, 1.1 * S)   # slightly softened copy for shading terms

    # ---------------------------------------------------------------- albedo
    # Palette is linear and deliberately shares the kahgel wall's family.
    dust_dark  = np.array([0.400, 0.302, 0.204], np.float32)
    dust_light = np.array([0.659, 0.549, 0.396], np.float32)
    adobe_dark = np.array([0.300, 0.190, 0.132], np.float32)
    adobe_lite = np.array([0.560, 0.408, 0.288], np.float32)
    kahgel_col = np.array([0.470, 0.325, 0.212], np.float32)
    gypsum     = np.array([0.640, 0.592, 0.520], np.float32)
    stone_grey = np.array([0.400, 0.380, 0.350], np.float32)
    soot       = np.array([0.090, 0.075, 0.065], np.float32)
    straw_col  = np.array([0.620, 0.520, 0.300], np.float32)

    # dust bed: height-driven light/dark plus broad tonal drift
    drift = T.fbm(res, 6, 5, seed=seed + 50)
    tone = np.clip(hb * 0.75 + drift * 0.45, 0, 1)[..., None]
    alb = T.mix(dust_dark, dust_light, tone)
    del drift

    def paint(mask, chash, col_a, col_b, jitter_seed):
        """Tint a chunk layer, giving every individual chunk its own shade."""
        v = np.clip(chash[..., None] * 0.80
                    + T.fbm(res, 30, 4, seed=jitter_seed)[..., None] * 0.20, 0, 1)
        return T.mix(col_a, col_b, v), mask[..., None]

    # slabs: mostly kahgel-faced, some pale gypsum/plaster backing
    c, m = paint(slab_m, slab_id, kahgel_col, adobe_lite, seed + 51)
    gyp = (slab_id > 0.82)[..., None].astype(np.float32)   # ~18% of slabs
    c = T.mix(c, gypsum, gyp * 0.62)   # dusty plaster, not chalk white
    alb = T.mix(alb, c, m)
    del c, m, gyp

    # bricks: adobe range
    c, m = paint(brick_m, brick_id, adobe_dark, adobe_lite, seed + 52)
    alb = T.mix(alb, c, m)
    del c, m

    # spall: kahgel lumps with the odd grey stone
    c, m = paint(spall_m, spall_id, kahgel_col, dust_light, seed + 53)
    stone = (spall_id > 0.86)[..., None].astype(np.float32)  # ~14% of spall
    c = T.mix(c, stone_grey, stone * 0.8)
    alb = T.mix(alb, c, m)
    del c, m, stone

    # pulverised gypsum dusting settling in the hollows and on flat tops
    fines = T.sstep(T.fbm(res, 22, 5, seed=seed + 54), 0.52, 0.88)
    fines *= T.sstep(1.0 - T.nrm(np.abs(np.gradient(hb)[0]) +
                                 np.abs(np.gradient(hb)[1])), 0.35, 0.95)
    alb = T.mix(alb, gypsum, (fines * 0.45)[..., None])

    # scorching around the worst of the collapse
    burn = T.sstep(T.warp(T.fbm(res, 4, 5, seed=seed + 55),
                          T.fbm(res, 11, 4, seed=seed + 56),
                          T.fbm(res, 11, 4, seed=seed + 57), 34 * S), 0.66, 0.95)
    alb = T.mix(alb, soot, (burn * 0.55)[..., None])

    # straw fibres pulled out of the broken kahgel
    straw = T.blur(T.fbm(res, 120, 3, seed=seed + 58) - 0.5, (0.5 * S, 3.0 * S))
    straw_m = T.sstep(T.nrm(straw), 0.80, 0.97) * (1.0 - burn)
    alb = T.mix(alb, straw_col, (straw_m * 0.30)[..., None])
    del straw

    # ambient dust film ties the whole tile together
    alb = T.mix(alb, dust_light, (T.sstep(hb, 0.55, 1.0) * 0.16)[..., None])
    # NOTE: srgb_noise returns 1.0 +/- amt, i.e. a MULTIPLIER. Adding it blows
    # every channel past 1.0 and the albedo clips to solid white.
    alb = np.clip(alb * T.srgb_noise((res, res, 1), rng, 0.035), 0, 1)

    # ---------------------------------------------------------------- ORM
    # Rubble is deeply occluded - the gaps between chunks are near-black.
    ao = T.ao_from_height(h, radius=30, strength=1.25)
    ao *= 1.0 - T.sstep(gouge_m, 0.2, 1.0) * 0.20
    ao = np.clip(ao, 0.0, 1.0)

    rough = np.full((res, res), 0.90, np.float32)
    rough += fines * 0.06          # pulverised gypsum is very matt
    rough += straw_m * 0.04
    rough += burn * 0.03
    rough -= slab_m * 0.06         # intact kahgel faces are slightly smoother
    rough -= brick_m * 0.04
    rough += (T.fbm(res, 14, 5, seed=seed + 60) - 0.5) * 0.08
    rough += (T.fbm(res, 52, 4, seed=seed + 61) - 0.5) * 0.05
    rough = np.clip(rough, 0.55, 1.0)

    metal = np.zeros((res, res), np.float32)
    orm = np.stack([ao, rough, metal], -1)
    del ao, rough, metal, fines, burn, straw_m, gouge_m
    del slab_h, brick_h, spall_h, slab_m, brick_m, spall_m, slab_id, brick_id, spall_id
    gc.collect()

    # ---------------------------------------------------------------- normals
    # Calibrated at 2048 against the saved height map (see MATERIAL_RECORDS).
    # Measure normals in PACKED space (nz*0.5+0.5) to compare with the kahgel
    # wall's 0.826: strength 4.0 -> actual nz 0.593 -> packed 0.797, i.e. a bit
    # more relief than the wall, which is right for debris.
    nrmmap = T.to_dx(T.normal_from_height(h, strength=4.0, res_scale=S))

    # Detail normal (tiles ~8x): sand grain, grit and straw fibre. Deliberately
    # light on worley F1, whose round cells read as popcorn at 2K.
    dh = (T.fbm(res, 80, 5, seed=seed + 70) * 0.36
          + T.blur(T.fbm(res, 150, 3, seed=seed + 71) - 0.5,
                   (0.5 * S, 2.4 * S)) * 0.28
          + T.worley(res, 120, seed=seed + 72, kind='F1') * 0.12
          + T.fbm(res, 165, 3, seed=seed + 73) * 0.24)
    dn = T.to_dx(T.normal_from_height(T.nrm(dh), strength=0.95, res_scale=S))
    del dh, hb
    gc.collect()

    return dict(albedo=alb, normal=nrmmap, detail_normal=dn, height=h, orm=orm)
