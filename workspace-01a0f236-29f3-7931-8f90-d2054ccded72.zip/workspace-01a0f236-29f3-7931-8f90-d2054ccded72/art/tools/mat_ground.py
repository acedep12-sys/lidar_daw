"""T_Village_GroundDirt — dry compacted earth track / village ground.

Khuzestan / Dehlavieh reference (دفاع مقدس). This is the surface the player
spends the most time looking at, almost always at a grazing angle and tiled many
times across the view, which drives every decision here:

* NO strong, recognisable macro features. Anything distinctive (a big rut, a
  dark blotch) becomes an obvious repeating stamp once the material tiles across
  a road. Macro variation is kept broad and low-contrast; the character lives in
  the high-frequency detail instead.
* Read at a grazing angle comes almost entirely from the NORMAL and ROUGHNESS,
  not the albedo. The albedo is deliberately close-valued and dusty.
* Flatter than the wall and the rubble - see the packed-nz calibration below.

Lessons already baked in (see MATERIAL_RECORDS.md):
  - srgb_noise is a MULTIPLIER (1.0 +/- amt), never added.
  - Worley distances that get thresholded are kept in RAW cell units.
  - Colour/variant selection uses a hash DECORRELATED from the presence hash.
  - Normal strength is calibrated at 2048 and quoted in PACKED space.
"""
import gc, sys, numpy as np
sys.path.insert(0, '/home/user/art/tools')
import texlib as T

# _cells gives wrapped cellular noise with a per-cell identity, which is what
# scattered pebbles need. It lives in the rubble module rather than being
# duplicated here.
from mat_rubble import _cells


def build(res=2048, seed=3401):
    rng = np.random.default_rng(seed)
    S = res / 2048.0

    # ------------------------------------------------------------ base ground
    # Broad, low-contrast undulation. Deliberately gentle: a dirt road is close
    # to planar, and strong macro shapes tile visibly.
    base = (T.fbm(res, 4,  7, seed=seed + 1) * 0.50
            + T.fbm(res, 13, 6, seed=seed + 2) * 0.30
            + T.fbm(res, 41, 5, seed=seed + 3) * 0.20)
    base = T.nrm(base)
    # let it settle so hollows silt up and ridges round over
    base = T.erode(base, iters=20, rate=0.20, seed=seed + 4)

    # Compaction map: where traffic has packed the earth smooth and hard, versus
    # loose soil that stays fluffy. Drives height, roughness AND colour, which is
    # what sells it as a used track rather than generic noise.
    compact = T.warp(T.fbm(res, 3, 5, seed=seed + 5),
                     T.fbm(res, 8, 4, seed=seed + 6),
                     T.fbm(res, 8, 4, seed=seed + 7), 40 * S)
    compact = T.sstep(T.nrm(compact), 0.30, 0.78)

    # Compacted areas are lower and smoother.
    h = base * (1.0 - compact * 0.45) - compact * 0.05
    del base

    # ------------------------------------------------------- directional wear
    # Anisotropic streaking along the direction of travel. Faint, and produced by
    # blurring noise rather than by drawing explicit ruts, so there is no single
    # rut shape to repeat when the material tiles.
    wear = T.blur(T.fbm(res, 18, 5, seed=seed + 8) - 0.5, (2.2 * S, 9.0 * S))
    wear = T.nrm(wear)
    h -= (wear - 0.5) * 0.045 * compact

    # ------------------------------------------------------------ mud cracking
    # Dried cracks form where fines settled, i.e. in the compacted low areas.
    crack_cells = T.worley(res, 22, seed=seed + 9, kind='F2F1')
    crack_cells = T.warp(crack_cells,
                         T.fbm(res, 14, 4, seed=seed + 10),
                         T.fbm(res, 14, 4, seed=seed + 11), 9 * S)
    # F2F1 is ~0 exactly on a cell boundary, so a LOW threshold isolates the seam.
    crack = (1.0 - T.sstep(crack_cells, 0.02, 0.14))
    crack *= T.sstep(compact, 0.25, 0.75)
    # A tight patch gate bunched every crack into one blob, which tiles as an
    # obvious repeating stamp. Keep them broad and low-contrast instead.
    crack *= 0.35 + 0.65 * T.sstep(T.fbm(res, 11, 5, seed=seed + 12), 0.30, 0.85)
    h -= crack * 0.045
    del crack_cells

    # ------------------------------------------------------------ pebbles
    # Small stones pressed into the surface. Only a minority of cells carry one,
    # and they are shallow: proud pebbles read as gravel, not as a road.
    pd, pedge, pid, _ly, _lx = _cells(res, 62, seed + 13, angular=0.35)  # tilt coords unused here
    peb_present = (pid < 0.30).astype(np.float32)
    peb = (1.0 - T.sstep(pd, 0.16, 0.34)) * peb_present
    peb = T.blur(peb, 0.5)
    # bed them down where the ground is compacted (driven in), leave them
    # proud in loose soil
    peb_h = peb * (0.055 - compact * 0.030)
    h += peb_h
    peb_m = T.sstep(peb, 0.25, 0.65)
    # decorrelated identity for per-pebble colour (see lesson 3)
    peb_id = T.hash01((pid * 65535.0).astype(np.int32), salt=17)
    del pd, pedge, peb_present, peb_h, _ly, _lx

    # ------------------------------------------------------------ fine tooth
    # Micro amplitude kept low: at 2K a strong worley F1 here reads as dark
    # salt-and-pepper speckle (crumbly gravel), not a packed dirt road.
    h += (T.fbm(res, 80, 5, seed=seed + 14) - 0.5) * 0.022
    h += (T.blur(T.worley(res, 150, seed=seed + 15, kind='F1'), 0.7) - 0.5) * 0.008
    h = T.nrm(h)
    hb = T.blur(h, 1.2 * S)

    # ------------------------------------------------------------ albedo
    earth_dark  = np.array([0.315, 0.238, 0.166], np.float32)   # damp/compacted
    earth_mid   = np.array([0.505, 0.398, 0.276], np.float32)
    dust_light  = np.array([0.690, 0.588, 0.435], np.float32)   # dry surface dust
    sun_bleach  = np.array([0.748, 0.668, 0.520], np.float32)
    stone_grey  = np.array([0.412, 0.392, 0.360], np.float32)
    stone_warm  = np.array([0.520, 0.440, 0.340], np.float32)
    straw_col   = np.array([0.620, 0.520, 0.300], np.float32)

    # Height/dust driven base tone, then compaction darkens the packed track.
    drift = T.fbm(res, 5, 6, seed=seed + 20)
    tone = np.clip(0.18 + hb * 0.58 + drift * 0.50, 0, 1)[..., None]
    alb = T.mix(earth_mid, dust_light, tone)
    alb = T.mix(alb, earth_dark, (compact * 0.18)[..., None])
    del drift

    # Sun-bleached high points and loose dust on the ridges.
    alb = T.mix(alb, sun_bleach, (T.sstep(hb, 0.58, 1.0) * 0.30 * (1.0 - compact))[..., None])

    # Cracks are dark: they are gaps, and they self-shadow.
    alb = T.mix(alb, earth_dark, (crack * 0.45)[..., None])

    # Pebbles: mostly warm, some grey.
    pcol = T.mix(stone_warm, stone_grey, peb_id[..., None])
    alb = T.mix(alb, pcol, (peb_m * 0.88)[..., None])
    del pcol

    # Scattered dry straw / chaff blown across the track.
    straw = T.blur(T.fbm(res, 130, 3, seed=seed + 21) - 0.5, (1.1 * S, 2.6 * S))
    straw_m = T.sstep(T.nrm(straw), 0.86, 0.985) * (1.0 - compact * 0.5)
    alb = T.mix(alb, straw_col, (straw_m * 0.18)[..., None])
    del straw

    # Overall dust film - unifies the tile and keeps the value range tight.
    alb = T.mix(alb, dust_light, (T.sstep(T.fbm(res, 9, 5, seed=seed + 22), 0.30, 0.95) * 0.26)[..., None])
    alb = np.clip(alb * T.srgb_noise((res, res, 1), rng, 0.030), 0, 1)

    # ------------------------------------------------------------ ORM
    # Softer than the wall/rubble: a road has shallow occlusion, and a strong AO
    # here reads as dark grit speckle over the whole tile.
    ao = T.ao_from_height(h, radius=22, strength=0.62)
    ao *= 1.0 - crack * 0.22          # cracks occlude hard
    ao = np.clip(ao, 0.0, 1.0)

    # Roughness carries the "polished by traffic" read that makes a track legible
    # at grazing angles.
    rough = np.full((res, res), 0.88, np.float32)
    rough -= compact * 0.20           # packed earth is burnished
    rough -= (wear - 0.5) * 0.10 * compact
    rough -= peb_m * 0.10             # stones are smoother than soil
    rough += crack * 0.05
    rough += straw_m * 0.04
    rough += (T.fbm(res, 16, 5, seed=seed + 23) - 0.5) * 0.09
    rough += (T.fbm(res, 58, 4, seed=seed + 24) - 0.5) * 0.05
    rough = np.clip(rough, 0.42, 1.0)

    metal = np.zeros((res, res), np.float32)
    orm = np.stack([ao, rough, metal], -1)
    del ao, rough, metal, crack, compact, wear, peb, peb_m, peb_id, straw_m, pid
    gc.collect()

    # ------------------------------------------------------------ normals
    # Calibrated at 2048 off the saved height map, quoted in PACKED space
    # (nz*0.5+0.5) so it is comparable with the other village surfaces:
    #   kahgel wall 0.826 | rubble 0.797 | ground 0.875 (flattest, correct for a road)
    # strength 2.2 gave packed 0.839 - MORE relief than the wall, which made the
    # surface read as coarse broken soil instead of a packed track.
    nrmmap = T.to_dx(T.normal_from_height(h, strength=1.7, res_scale=S))

    # Detail normal (~8x): sand grain and grit. This is what holds the surface
    # together underfoot, where the base normal is too coarse to resolve.
    # DN strength is much lower here than on the wall (0.9) or rubble (0.95).
    # Those surfaces have enough base relief to carry the read; a correctly FLAT
    # road does not, so at 6-8x tiling a strong detail normal takes over the
    # whole surface and covers it in dark grit speckle - which is what made
    # earlier passes look like coarse broken soil rather than a packed track.
    dh = (T.fbm(res, 70, 5, seed=seed + 30) * 0.46
          + T.fbm(res, 120, 4, seed=seed + 31) * 0.30
          + T.blur(T.worley(res, 110, seed=seed + 32, kind='F1'), 1.0) * 0.10
          + T.fbm(res, 150, 3, seed=seed + 33) * 0.14)
    dn = T.to_dx(T.normal_from_height(T.nrm(dh), strength=0.42, res_scale=S))
    del dh, hb
    gc.collect()

    return dict(albedo=alb, normal=nrmmap, detail_normal=dn, height=h, orm=orm)
